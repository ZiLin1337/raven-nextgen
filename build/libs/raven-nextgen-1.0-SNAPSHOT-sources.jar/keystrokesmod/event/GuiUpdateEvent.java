package keystrokesmod.event;

import net.minecraft.class_437;

public class GuiUpdateEvent extends Event {
    private class_437 guiScreen;
    private boolean opened;
    public GuiUpdateEvent(class_437 guiScreen, boolean opened) { this.guiScreen = guiScreen; this.opened = opened; }
    public class_437 getScreen() { return guiScreen; }
    public boolean isOpened() { return opened; }
}
