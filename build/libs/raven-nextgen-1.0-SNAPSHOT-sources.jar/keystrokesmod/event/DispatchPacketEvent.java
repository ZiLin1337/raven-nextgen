package keystrokesmod.event;

import net.minecraft.class_2596;

public class DispatchPacketEvent extends Event {
    private class_2596<?> packet;
    public DispatchPacketEvent(class_2596<?> packet) { this.packet = packet; }
    public class_2596<?> getPacket() { return packet; }
}
