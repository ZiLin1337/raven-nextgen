package keystrokesmod.event;

import net.minecraft.class_2743;

public class PreEntityVelocityEvent extends Event {
    private boolean cancelled;

    public PreEntityVelocityEvent(class_2743 packet) {
    }

    public boolean isCancelled() { return cancelled; }
    public void setCancelled(boolean c) { this.cancelled = c; }
}
