package keystrokesmod.event;

import net.minecraft.class_1297;
import net.minecraft.class_243;

public class PreAttackEvent extends Event {
    private class_1297 target;
    private class_243 hitVec;
    private boolean reachModified;
    public PreAttackEvent(class_1297 target) { this.target = target; }
    public class_1297 getTarget() { return target; }
    public void setTarget(class_1297 target) { this.target = target; }
    public class_243 getHitVec() { return hitVec; }
    public void setHitVec(class_243 hitVec) { this.hitVec = hitVec; }
    public boolean isReachModified() { return reachModified; }
    public void setReachModified(boolean b) { this.reachModified = b; }
}
