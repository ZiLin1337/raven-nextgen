package keystrokesmod.event;

import net.minecraft.class_638;

public class WorldEvent extends Event {
    public static class Load extends WorldEvent {
        public final class_638 world;

        public Load(class_638 world) {
            this.world = world;
        }
    }
}
