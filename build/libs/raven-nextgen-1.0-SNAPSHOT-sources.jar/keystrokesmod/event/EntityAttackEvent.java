package keystrokesmod.event;

import net.minecraft.class_1297;

public class EntityAttackEvent extends AttackEvent {
    public EntityAttackEvent(class_1297 target) {
        super(target);
    }
}
