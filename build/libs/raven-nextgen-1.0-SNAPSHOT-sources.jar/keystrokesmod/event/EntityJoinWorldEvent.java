package keystrokesmod.event;

import net.minecraft.class_1297;
import net.minecraft.class_638;

public class EntityJoinWorldEvent extends Event {
    public final class_1297 entity;
    public final class_638 world;

    public EntityJoinWorldEvent(class_1297 entity, class_638 world) {
        this.entity = entity;
        this.world = world;
    }
}
