package keystrokesmod.event;

import net.minecraft.class_1297;

public class AttackEvent extends Event {
    private class_1297 target;
    public AttackEvent(class_1297 target) { this.target = target; }
    public class_1297 getTarget() { return target; }
    public void setTarget(class_1297 target) { this.target = target; }
}
