package keystrokesmod.event;

import net.minecraft.class_2596;

public class SendPacketEvent extends Event {
    private class_2596<?> packet;

    public SendPacketEvent(class_2596<?> packet) {
        this.packet = packet;
    }

    public class_2596<?> getPacket() {
        return packet;
    }

    public void setPacket(class_2596<?> packet) {
        this.packet = packet;
    }
}
