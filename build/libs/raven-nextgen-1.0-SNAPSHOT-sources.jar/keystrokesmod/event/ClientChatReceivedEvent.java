package keystrokesmod.event;

import net.minecraft.class_2561;

public class ClientChatReceivedEvent extends Event {
    public class_2561 message;

    public ClientChatReceivedEvent(class_2561 message) {
        this.message = message;
    }
}
