package keystrokesmod.event;

import net.minecraft.class_1297;
public class PostAttackEvent {
    private class_1297 target;
    public PostAttackEvent(class_1297 t) { this.target = t; }
    public class_1297 getTarget() { return target; }
}