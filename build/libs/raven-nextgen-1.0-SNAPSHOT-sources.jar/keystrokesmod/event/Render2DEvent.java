package keystrokesmod.event;

import net.minecraft.class_332;

/**
 * 1.21.4 compatible Render2D event
 */
public class Render2DEvent extends Event {
    public final class_332 drawContext;
    public final int screenWidth;
    public final int screenHeight;
    public final float tickDelta;
    
    public Render2DEvent(class_332 drawContext, int screenWidth, int screenHeight, float tickDelta) {
        this.drawContext = drawContext;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.tickDelta = tickDelta;
    }
}
