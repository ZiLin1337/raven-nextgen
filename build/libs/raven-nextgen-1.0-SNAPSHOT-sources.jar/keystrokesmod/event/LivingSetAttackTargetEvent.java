package keystrokesmod.event;

import net.minecraft.class_1309;

public class LivingSetAttackTargetEvent extends Event {
    public final class_1309 entity;
    public final class_1309 target;

    public LivingSetAttackTargetEvent(class_1309 entity, class_1309 target) {
        this.entity = entity;
        this.target = target;
    }
}
