package keystrokesmod.event;

import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;

public class CollisionEvent extends Event {
    public class_2338 pos;
    public class_2680 state;
    public class_238 boundingBox;
    private boolean cancelled;

    public CollisionEvent(class_2338 pos, class_2680 state, class_238 boundingBox) {
        this.pos = pos;
        this.state = state;
        this.boundingBox = boundingBox;
    }

    public boolean isCancelled() { return cancelled; }
    public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }
}