package keystrokesmod.event.impl;

import net.minecraft.class_2596;

/**
 * 1.21.4 compatible SendPacket event
 */
public class SendPacketEvent {
    public final class_2596<?> packet;
    public boolean cancelled = false;
    
    public SendPacketEvent(class_2596<?> packet) {
        this.packet = packet;
    }
    
    public void cancel() {
        this.cancelled = true;
    }
}
