package keystrokesmod.event;

import net.minecraft.class_2596;

public class PreExplosionPacketEvent extends Event {
    private class_2596<?> packet;
    public PreExplosionPacketEvent(class_2596<?> packet) { this.packet = packet; }
    public class_2596<?> getPacket() { return packet; }
}
