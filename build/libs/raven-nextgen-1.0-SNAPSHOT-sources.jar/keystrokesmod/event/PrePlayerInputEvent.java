package keystrokesmod.event;

public class PrePlayerInputEvent extends Event {
    private float forward, strafe;
    private boolean jump, sneak;
    private double sneakSlowDownMultiplier;

    public PrePlayerInputEvent(float forward, float strafe, boolean jump, boolean sneak, double sneakSlowDownMultiplier) {
        this.forward = forward;
        this.strafe = strafe;
        this.jump = jump;
        this.sneak = sneak;
        this.sneakSlowDownMultiplier = sneakSlowDownMultiplier;
    }

    public float getForward() { return forward; }
    public void setForward(float forward) { this.forward = forward; }
    public float getStrafe() { return strafe; }
    public void setStrafe(float strafe) { this.strafe = strafe; }
    public boolean isJump() { return jump; }
    public void setJump(boolean jump) { this.jump = jump; }
    public boolean isSneak() { return sneak; }
    public void setSneak(boolean sneak) { this.sneak = sneak; }
    public double getSneakSlowDownMultiplier() { return sneakSlowDownMultiplier; }
    public void setSneakSlowDownMultiplier(double mult) { this.sneakSlowDownMultiplier = mult; }
    public float getYaw() { return 0.0F; }
    public float getPitch() { return 0.0F; }
}
