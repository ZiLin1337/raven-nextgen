package keystrokesmod.event;

import net.minecraft.class_437;

public class GuiOpenEvent extends Event {
    public class_437 gui;

    public GuiOpenEvent(class_437 gui) {
        this.gui = gui;
    }
}
