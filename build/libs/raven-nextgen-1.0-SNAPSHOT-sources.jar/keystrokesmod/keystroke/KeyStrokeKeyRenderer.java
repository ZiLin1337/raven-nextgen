package keystrokesmod.keystroke;

import net.minecraft.class_310;
import net.minecraft.class_332;

public class KeyStrokeKeyRenderer {
    private static class_310 mc = class_310.method_1551();
    private int x, y;
    private String key;
    private int keyCode;

    public KeyStrokeKeyRenderer(int x, int y, String key, int keyCode) {
        this.x = x;
        this.y = y;
        this.key = key;
        this.keyCode = keyCode;
    }

    public void render(class_332 context) {
        boolean pressed = org.lwjgl.glfw.GLFW.glfwGetKey(mc.method_22683().method_4490(), keyCode) == 1;
        int bgColor = pressed ? 0xFF00AA00 : 0x80000000;
        int textColor = pressed ? 0xFFFFFFFF : 0xFFAAAAAA;

        context.method_25294(x, y, x + 14, y + 14, bgColor);
        context.method_51433(mc.field_1772, key, x + 3, y + 3, textColor, true);
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
}
