package keystrokesmod.keystroke;

import keystrokesmod.Raven;
import keystrokesmod.helper.InputUtil;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.utility.Utils;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class KeyStrokeRenderer {
    private static class_310 mc = class_310.method_1551();
    private int x, y;

    public KeyStrokeRenderer(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void render(class_332 context) {
        int yOff = y;
        context.method_25294(x, yOff, x + 30, yOff + 20, 0x80000000);
        context.method_51433(mc.field_1772, "W", x + 10, yOff + 5, 0xFFFFFFFF, true);
        yOff += 22;

        context.method_25294(x, yOff, x + 14, yOff + 14, 0x80000000);
        context.method_51433(mc.field_1772, "A", x + 3, yOff + 2, 0xFFFFFFFF, true);
        context.method_25294(x + 16, yOff, x + 30, yOff + 14, 0x80000000);
        context.method_51433(mc.field_1772, "S", x + 19, yOff + 2, 0xFFFFFFFF, true);
        yOff += 16;

        context.method_25294(x + 8, yOff, x + 22, yOff + 14, 0x80000000);
        context.method_51433(mc.field_1772, "D", x + 12, yOff + 2, 0xFFFFFFFF, true);
        yOff += 18;

        int cps = InputUtil.getLeftCPS();
        context.method_25294(x, yOff, x + 14, yOff + 14, 0x80000000);
        context.method_51433(mc.field_1772, String.valueOf(cps), x + 2, yOff + 2, 0xFF00FF00, true);
        context.method_25294(x + 16, yOff, x + 30, yOff + 14, 0x80000000);
        int rcps = InputUtil.getRightCPS();
        context.method_51433(mc.field_1772, String.valueOf(rcps), x + 18, yOff + 2, 0xFF00FF00, true);
    }
}
