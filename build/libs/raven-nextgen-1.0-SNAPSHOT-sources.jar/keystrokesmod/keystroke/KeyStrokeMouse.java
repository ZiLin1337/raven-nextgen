package keystrokesmod.keystroke;

import keystrokesmod.helper.InputUtil;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class KeyStrokeMouse {
    private static class_310 mc = class_310.method_1551();
    private int x, y;

    public KeyStrokeMouse(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void render(class_332 context) {
        int lcps = InputUtil.getLeftCPS();
        int rcps = InputUtil.getRightCPS();

        context.method_25294(x, y, x + 28, y + 14, 0x80000000);
        context.method_51433(mc.field_1772, "L" + lcps, x + 2, y + 2, 0xFF00FF00, true);

        context.method_25294(x, y + 16, x + 28, y + 30, 0x80000000);
        context.method_51433(mc.field_1772, "R" + rcps, x + 2, y + 18, 0xFF00FF00, true);
    }
}
