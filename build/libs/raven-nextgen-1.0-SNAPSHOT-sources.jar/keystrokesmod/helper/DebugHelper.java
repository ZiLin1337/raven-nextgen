package keystrokesmod.helper;

import net.minecraft.class_310;

public class DebugHelper {
    public static String getMinecraftVersion() {
        return class_310.method_1551().method_1515();
    }
}