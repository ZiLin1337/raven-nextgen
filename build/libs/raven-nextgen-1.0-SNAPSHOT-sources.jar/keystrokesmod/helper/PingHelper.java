package keystrokesmod.helper;

import keystrokesmod.Raven;
import keystrokesmod.utility.Utils;
import net.minecraft.class_640;

public class PingHelper {
    public static int getPing() {
        if (Raven.mc.method_1562() == null || Raven.mc.field_1724 == null) return 0;
        class_640 entry = Raven.mc.method_1562().method_2871(Raven.mc.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959();
    }

    public static String getPingFormatted() {
        int ping = getPing();
        String color = ping < 50 ? "&a" : ping < 150 ? "&e" : "&c";
        return color + ping + "ms";
    }
}
