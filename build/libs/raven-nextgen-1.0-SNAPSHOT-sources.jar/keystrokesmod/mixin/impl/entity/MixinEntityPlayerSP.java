package keystrokesmod.mixin.impl.entity;

import com.mojang.authlib.GameProfile;
import keystrokesmod.Raven;
import keystrokesmod.event.*;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class MixinEntityPlayerSP extends class_742 {

    @Shadow @Final public class_634 networkHandler;
    @Shadow public net.minecraft.class_744 input;

    private static final class_310 mc = class_310.method_1551();
    @Unique private boolean raven$cancelSend = false;

    public MixinEntityPlayerSP(net.minecraft.class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void onUpdatePre(CallbackInfo c) {
        Raven.EVENT_BUS.post(new PreUpdateEvent());
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void onUpdatePost(CallbackInfo c) {
        Raven.EVENT_BUS.post(new PostUpdateEvent());
    }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void onSendMovementPacketsHead(CallbackInfo ci) {
        class_746 self = (class_746)(Object)this;
        PreMotionEvent pre = new PreMotionEvent(self.method_23317(), self.method_23318(), self.method_23321(), self.method_36454(), self.method_36455(), self.method_24828(), self.method_5624(), self.method_5715());
        Raven.EVENT_BUS.post(pre);
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void onSendMovementPacketsReturn(CallbackInfo ci) {
        Raven.EVENT_BUS.post(new PostMotionEvent());
    }

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovement(CallbackInfo ci) { }
}
