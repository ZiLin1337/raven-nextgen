package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_1496;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1496.class)
public class MixinAbstractHorseEntity {
    // InventoryMove - 马上移动
}
