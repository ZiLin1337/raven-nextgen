package keystrokesmod.mixin.impl.entity;

import keystrokesmod.Raven;
import net.minecraft.class_1496;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1496.class)
public class MixinAbstractHorseEntity {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        // 马实体Tick
        // 可用于InventoryMove模块
    }
}
