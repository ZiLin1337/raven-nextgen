package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_636.class)
public class MixinClientPlayerInteractionManager {
}
