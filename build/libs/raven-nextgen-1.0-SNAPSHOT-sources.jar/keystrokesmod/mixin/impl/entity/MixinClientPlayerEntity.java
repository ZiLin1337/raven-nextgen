package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_746.class)
public class MixinClientPlayerEntity {
}
