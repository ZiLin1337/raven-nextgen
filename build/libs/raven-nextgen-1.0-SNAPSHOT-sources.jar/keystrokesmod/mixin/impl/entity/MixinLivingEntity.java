package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1309.class)
public class MixinLivingEntity {
}