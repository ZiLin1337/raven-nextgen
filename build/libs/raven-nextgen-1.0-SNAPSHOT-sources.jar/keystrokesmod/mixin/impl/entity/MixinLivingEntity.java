package keystrokesmod.mixin.impl.entity;

import keystrokesmod.Raven;
import keystrokesmod.event.JumpEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class MixinLivingEntity extends class_1297 {
    public MixinLivingEntity(net.minecraft.class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void onJump(CallbackInfo ci) {
        keystrokesmod.Raven.EVENT_BUS.post(new JumpEvent());
        // will be extended later
    }
}
