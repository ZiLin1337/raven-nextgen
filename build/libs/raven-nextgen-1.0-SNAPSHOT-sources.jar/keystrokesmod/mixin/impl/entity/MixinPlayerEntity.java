package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1657.class)
public class MixinPlayerEntity {
}
