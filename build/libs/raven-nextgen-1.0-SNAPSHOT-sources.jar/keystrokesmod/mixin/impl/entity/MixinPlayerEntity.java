package keystrokesmod.mixin.impl.entity;

import keystrokesmod.Raven;
import keystrokesmod.event.*;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public class MixinPlayerEntity {

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void onAttack(class_1297 target, CallbackInfo ci) {
        if (((Object) this) instanceof net.minecraft.class_746) {
            PreAttackEvent event = new PreAttackEvent(target);
            Raven.EVENT_BUS.post(event);
            if (event.isCancelled()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "attack", at = @At("RETURN"))
    private void onAttackPost(class_1297 target, CallbackInfo ci) {
        if (((Object) this) instanceof net.minecraft.class_746) {
            Raven.EVENT_BUS.post(new PostAttackEvent(target));
        }
    }

    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamage(net.minecraft.class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (((Object) this) instanceof net.minecraft.class_746) {
            Raven.EVENT_BUS.post(new EntityAttackEvent((net.minecraft.class_1297)(Object)this));
        }
    }
}
