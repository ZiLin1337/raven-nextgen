package keystrokesmod.mixin.impl.entity;

import keystrokesmod.Raven;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public abstract class MixinPlayerEntity extends class_1309 {
    protected MixinPlayerEntity(net.minecraft.class_1299<? extends class_1309> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void onAttack(class_1297 target, CallbackInfo ci) {
        // hook
    }
}
