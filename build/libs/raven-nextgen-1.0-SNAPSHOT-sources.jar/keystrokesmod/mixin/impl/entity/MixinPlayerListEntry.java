package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_640.class)
public class MixinPlayerListEntry {
}
