package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_742.class)
public class MixinAbstractClientPlayerEntity {
}
