package keystrokesmod.mixin.impl.entity;

import keystrokesmod.Raven;
import net.minecraft.class_1303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1303.class)
public class MixinExperienceOrbEntity {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        // 经验球Tick
        // 可用于ItemESP模块
    }
}
