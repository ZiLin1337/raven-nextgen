package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_1303;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1303.class)
public class MixinExperienceOrbEntity {
    // ItemESP - 经验球渲染
}
