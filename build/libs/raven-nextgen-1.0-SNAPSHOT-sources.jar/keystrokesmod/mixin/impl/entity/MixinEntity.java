package keystrokesmod.mixin.impl.entity;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1297.class)
public class MixinEntity {
}