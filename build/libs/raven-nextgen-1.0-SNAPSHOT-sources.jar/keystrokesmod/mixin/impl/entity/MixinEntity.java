package keystrokesmod.mixin.impl.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import keystrokesmod.Raven;
import keystrokesmod.event.ClientLookEvent;
import keystrokesmod.event.PlayerMoveEvent;
import keystrokesmod.event.StepHeightEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public class MixinEntity {

    @Shadow public float stepHeight;

    @Inject(method = "move", at = @At("HEAD"))
    private void onMove(class_1313 type, class_243 movement, CallbackInfo ci) {
        if (((Object) this) instanceof class_746) {
            Raven.EVENT_BUS.post(new PlayerMoveEvent(movement.field_1352, movement.field_1351, movement.field_1350));
        }
    }

    @Inject(method = "changeLookDirection", at = @At("HEAD"))
    private void onChangeLookDirection(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if (((Object) this) != class_310.method_1551().field_1724) return;
        Raven.EVENT_BUS.post(new ClientLookEvent(0, 0));
    }

    @ModifyExpressionValue(method = "adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/Entity;stepHeight:F"))
    private float modifyStepHeight(float originalStepHeight) {
        if (!(((Object) this) instanceof class_746)) return originalStepHeight;
        StepHeightEvent event = new StepHeightEvent(originalStepHeight);
        Raven.EVENT_BUS.post(event);
        return event.getStepHeight();
    }
}