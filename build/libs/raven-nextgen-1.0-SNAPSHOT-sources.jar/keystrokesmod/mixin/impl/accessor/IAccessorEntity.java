package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1297.class)
public interface IAccessorEntity {
}
