package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_636.class)
public interface IAccessorPlayerControllerMP {
    @Accessor("blockBreakingCooldown")
    int getBlockBreakingCooldown();
    @Accessor("blockBreakingCooldown")
    void setBlockBreakingCooldown(int cooldown);
}