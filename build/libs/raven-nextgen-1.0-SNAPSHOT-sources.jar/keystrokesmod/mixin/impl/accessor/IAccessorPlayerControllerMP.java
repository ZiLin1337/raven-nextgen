package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_636.class)
public interface IAccessorPlayerControllerMP {
}
