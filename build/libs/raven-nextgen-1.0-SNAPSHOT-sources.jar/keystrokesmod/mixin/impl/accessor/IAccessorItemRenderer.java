package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_759.class)
public interface IAccessorItemRenderer {
}
