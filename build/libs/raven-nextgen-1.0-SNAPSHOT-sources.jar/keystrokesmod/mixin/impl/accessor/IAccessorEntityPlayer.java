package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1657.class)
public interface IAccessorEntityPlayer {
}
