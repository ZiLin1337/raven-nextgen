package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1309.class)
public interface IAccessorEntityLivingBase {
    @Accessor("jumping")
    boolean getJumping();
    @Accessor("jumping")
    void setJumping(boolean jumping);
}