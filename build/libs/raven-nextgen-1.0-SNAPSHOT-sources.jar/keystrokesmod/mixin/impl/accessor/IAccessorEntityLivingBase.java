package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1309.class)
public interface IAccessorEntityLivingBase {
}
