package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_2604;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2604.class)
public interface IAccessorS14PacketEntity {
}