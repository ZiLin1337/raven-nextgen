package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_5944;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5944.class)
public interface IAccessorShaderGroup {
}
