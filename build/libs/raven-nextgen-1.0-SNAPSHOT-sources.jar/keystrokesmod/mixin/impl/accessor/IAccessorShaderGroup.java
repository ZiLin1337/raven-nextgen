package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_279;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_279.class)
public interface IAccessorShaderGroup {
}