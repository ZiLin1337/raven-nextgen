package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_2535;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2535.class)
public interface IAccessorNetworkManager {
}