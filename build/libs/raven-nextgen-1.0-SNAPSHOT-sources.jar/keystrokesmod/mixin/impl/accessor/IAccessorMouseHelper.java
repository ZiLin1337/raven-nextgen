package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_312.class)
public interface IAccessorMouseHelper {
}
