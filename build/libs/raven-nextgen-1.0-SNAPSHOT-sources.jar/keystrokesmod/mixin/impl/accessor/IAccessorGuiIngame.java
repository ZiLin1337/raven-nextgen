package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_329.class)
public interface IAccessorGuiIngame {
}
