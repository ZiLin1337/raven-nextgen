package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_746.class)
public interface IAccessorEntityPlayerSP {
}
