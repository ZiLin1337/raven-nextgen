package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1792.class)
public interface IAccessorItemFood {
}
