package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_355;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_355.class)
public interface IAccessorGuiPlayerTabOverlay {
}
