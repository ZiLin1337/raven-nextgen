package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_3872;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3872.class)
public interface IAccessorGuiScreenBook {
}
