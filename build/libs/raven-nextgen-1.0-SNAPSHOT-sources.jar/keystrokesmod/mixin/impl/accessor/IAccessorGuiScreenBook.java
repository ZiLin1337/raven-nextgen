package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_473;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_473.class)
public interface IAccessorGuiScreenBook {
}