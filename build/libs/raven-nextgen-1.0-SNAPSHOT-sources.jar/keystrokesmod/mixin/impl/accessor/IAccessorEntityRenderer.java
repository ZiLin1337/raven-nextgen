package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_757.class)
public interface IAccessorEntityRenderer {
}