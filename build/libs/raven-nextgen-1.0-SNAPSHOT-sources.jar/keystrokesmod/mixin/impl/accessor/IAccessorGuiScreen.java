package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_437.class)
public interface IAccessorGuiScreen {
    @Accessor("textRenderer")
    net.minecraft.class_327 getTextRenderer();
}
