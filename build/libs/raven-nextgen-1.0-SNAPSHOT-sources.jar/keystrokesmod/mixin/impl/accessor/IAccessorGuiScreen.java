package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_437.class)
public interface IAccessorGuiScreen {
}
