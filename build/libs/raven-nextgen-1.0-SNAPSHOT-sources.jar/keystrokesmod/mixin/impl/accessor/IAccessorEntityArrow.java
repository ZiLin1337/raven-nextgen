package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_1667;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1667.class)
public interface IAccessorEntityArrow {
}