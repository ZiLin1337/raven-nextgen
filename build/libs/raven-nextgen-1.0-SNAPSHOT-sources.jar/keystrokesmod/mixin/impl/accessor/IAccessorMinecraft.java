package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_310.class)
public interface IAccessorMinecraft {
    @Accessor("itemUseCooldown")
    void setItemUseCooldown(int cooldown);
    
    @Accessor("itemUseCooldown")
    int getItemUseCooldown();

    @Invoker("doAttack")
    boolean callClickMouse();
}
