package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_310.class)
public interface IAccessorMinecraft {
}
