package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface IAccessorMinecraft {
    @Accessor("attackCooldown")
    int getAttackCooldown();
    @Accessor("attackCooldown")
    void setAttackCooldown(int cooldown);
    @Accessor("itemUseCooldown")
    int getItemUseCooldown();
    @Accessor("itemUseCooldown")
    void setItemUseCooldown(int cooldown);
}