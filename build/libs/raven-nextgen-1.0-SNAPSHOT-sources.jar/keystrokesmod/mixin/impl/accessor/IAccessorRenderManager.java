package keystrokesmod.mixin.impl.accessor;

import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_898.class)
public interface IAccessorRenderManager {
}
