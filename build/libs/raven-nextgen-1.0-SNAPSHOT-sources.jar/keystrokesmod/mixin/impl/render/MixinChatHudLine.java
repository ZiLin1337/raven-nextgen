package keystrokesmod.mixin.impl.render;

import net.minecraft.class_303;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_303.class)
public class MixinChatHudLine {
    // BetterChat - 聊天行
}
