package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_303.class)
public class MixinChatHudLine {
    @Inject(method = "draw", at = @At("HEAD"))
    private void onDraw(CallbackInfo ci) {
        // 聊天行绘制
        // 可用于BetterChat钩子
    }
}
