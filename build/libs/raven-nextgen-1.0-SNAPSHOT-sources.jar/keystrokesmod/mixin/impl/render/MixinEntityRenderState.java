package keystrokesmod.mixin.impl.render;

import net.minecraft.class_10017;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_10017.class)
public class MixinEntityRenderState {
}
