package keystrokesmod.mixin.impl.render;

import net.minecraft.class_5944;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5944.class)
public class MixinShaderProgram {
}
