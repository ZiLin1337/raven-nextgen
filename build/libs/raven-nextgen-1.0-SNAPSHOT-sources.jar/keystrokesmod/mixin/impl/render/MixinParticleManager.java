package keystrokesmod.mixin.impl.render;

import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_702.class)
public class MixinParticleManager {
    // NoRender - 粒子管理
}
