package keystrokesmod.mixin.impl.render;

import net.minecraft.class_822;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_822.class)
public class MixinBeaconBlockEntityRenderer {
    // StorageESP - 信标方块实体渲染
}
