package keystrokesmod.mixin.impl.render;

import net.minecraft.class_269;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_269.class)
public class MixinScoreboard {
    // HUD模块 - 计分板
}
