package keystrokesmod.mixin.impl.render;

import net.minecraft.class_350;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_350.class)
public class MixinEntryListWidget {
    // ClickGUI - 列表控件
}
