package keystrokesmod.mixin.impl.render;

import keystrokesmod.module.ModuleManager;
import net.minecraft.class_10055;
import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_972.class)
public class MixinLayerCape {

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(
        net.minecraft.class_4587 matrices,
        net.minecraft.class_4597 vertexConsumers,
        int light,
        class_10055 state,
        float f,
        float g,
        CallbackInfo ci) {
        // 披风渲染钩子 - CustomCapes模块可在此拦截
    }
}