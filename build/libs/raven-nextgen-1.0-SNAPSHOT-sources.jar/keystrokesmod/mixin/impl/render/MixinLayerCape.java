package keystrokesmod.mixin.impl.render;

import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_972.class)
public class MixinLayerCape {
}