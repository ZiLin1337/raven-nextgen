package keystrokesmod.mixin.impl.render;

import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_9779.class)
public class MixinRenderTickCounter {
}
