package keystrokesmod.mixin.impl.render;

import net.minecraft.class_337;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_337.class)
public class MixinBossBarHud {
}
