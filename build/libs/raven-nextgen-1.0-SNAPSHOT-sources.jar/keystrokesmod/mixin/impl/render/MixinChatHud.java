package keystrokesmod.mixin.impl.render;

import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_338.class)
public class MixinChatHud {
}
