package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_332.class)
public class MixinDrawContext {
    @Inject(method = "fill", at = @At("HEAD"))
    private void onFill(CallbackInfo ci) {
        // 绘制填充
        // 可用于ClickGUI钩子
    }
}
