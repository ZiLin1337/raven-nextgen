package keystrokesmod.mixin.impl.render;

import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_332.class)
public class MixinDrawContext {
}
