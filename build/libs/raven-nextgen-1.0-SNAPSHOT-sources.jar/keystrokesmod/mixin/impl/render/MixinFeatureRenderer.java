package keystrokesmod.mixin.impl.render;

import net.minecraft.class_3887;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3887.class)
public class MixinFeatureRenderer {
}
