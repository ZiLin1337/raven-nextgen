package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_3887;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3887.class)
public class MixinFeatureRenderer {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        // 特征渲染
        // 可用于Chams钩子
    }
}
