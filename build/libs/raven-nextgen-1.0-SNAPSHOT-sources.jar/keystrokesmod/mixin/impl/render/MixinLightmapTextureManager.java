package keystrokesmod.mixin.impl.render;

import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_765.class)
public class MixinLightmapTextureManager {
    // FullBright/NoRender - 光照贴图管理
}
