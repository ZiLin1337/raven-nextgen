package keystrokesmod.mixin.impl.render;

import net.minecraft.class_903;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_903.class)
public class MixinFireworkRocketEntityRenderer {
    // ESP - 烟花火箭渲染
}
