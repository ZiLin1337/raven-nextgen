package keystrokesmod.mixin.impl.render;

import net.minecraft.class_10039;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public class MixinRenderEntityItem {

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
    private void onRenderHead(
        class_10039 state,
        class_4587 matrices,
        class_4597 vertexConsumers,
        int light,
        CallbackInfo ci) {
        // 物品实体渲染钩子 - ItemPhysics模块
    }
}