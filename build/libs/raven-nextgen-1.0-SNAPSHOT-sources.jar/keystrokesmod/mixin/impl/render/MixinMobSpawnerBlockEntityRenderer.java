package keystrokesmod.mixin.impl.render;

import net.minecraft.class_839;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_839.class)
public class MixinMobSpawnerBlockEntityRenderer {
    // StorageESP - 刷怪笼渲染
}
