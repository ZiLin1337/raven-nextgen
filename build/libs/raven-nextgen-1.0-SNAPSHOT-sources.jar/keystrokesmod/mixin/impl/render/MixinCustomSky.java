package keystrokesmod.mixin.impl.render;

import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;

// 1.21.4没有OptiFine CustomSky，改用WorldRenderer渲染钩子
@Mixin(class_638.class)
public class MixinCustomSky {
}
