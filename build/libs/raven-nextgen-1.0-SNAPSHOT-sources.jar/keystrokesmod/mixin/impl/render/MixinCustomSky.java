package keystrokesmod.mixin.impl.render;

import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class MixinCustomSky {

    @Inject(method = "renderSky", at = @At("HEAD"))
    private void onRenderSky(
        net.minecraft.class_4587 matrices,
        net.minecraft.class_4597.class_4598 buffer,
        float tickDelta, boolean skipFog, CallbackInfo ci) {
    }
}
