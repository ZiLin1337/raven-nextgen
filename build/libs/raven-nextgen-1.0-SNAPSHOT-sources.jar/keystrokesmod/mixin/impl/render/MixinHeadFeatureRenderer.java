package keystrokesmod.mixin.impl.render;

import net.minecraft.class_976;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_976.class)
public class MixinHeadFeatureRenderer {
    // NameTags - 头部特征渲染
}
