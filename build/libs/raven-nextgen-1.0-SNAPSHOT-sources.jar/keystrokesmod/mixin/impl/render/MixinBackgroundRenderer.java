package keystrokesmod.mixin.impl.render;

import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_758.class)
public class MixinBackgroundRenderer {
    @Inject(method = "applyFog", at = @At("HEAD"))
    private static void onApplyFog(
        net.minecraft.class_4184 camera,
        class_758.class_4596 fogType,
        org.joml.Vector4f fogColor,
        float viewDistance,
        boolean thickFog,
        float tickDelta,
        CallbackInfo ci) {
        // NoRender/Fog模块 - 自定义雾效
    }
}
