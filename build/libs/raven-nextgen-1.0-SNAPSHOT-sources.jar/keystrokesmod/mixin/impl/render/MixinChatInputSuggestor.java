package keystrokesmod.mixin.impl.render;

import net.minecraft.class_4717;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_4717.class)
public class MixinChatInputSuggestor {
}
