package keystrokesmod.mixin.impl.render;

import net.minecraft.class_892;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_892.class)
public class MixinEndCrystalEntityRenderer {
    // ESP - 末影水晶渲染
}
