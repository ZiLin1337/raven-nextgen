package keystrokesmod.mixin.impl.render;

import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_970.class)
public class MixinArmorFeatureRenderer {
    // Chams/ESP - 盔甲渲染钩子
}
