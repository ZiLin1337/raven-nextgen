package keystrokesmod.mixin.impl.render;

import net.minecraft.class_327;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_327.class)
public class MixinTextRenderer {
}
