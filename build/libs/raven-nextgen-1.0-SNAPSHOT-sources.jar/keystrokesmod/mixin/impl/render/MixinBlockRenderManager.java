package keystrokesmod.mixin.impl.render;

import net.minecraft.class_776;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_776.class)
public class MixinBlockRenderManager {
}
