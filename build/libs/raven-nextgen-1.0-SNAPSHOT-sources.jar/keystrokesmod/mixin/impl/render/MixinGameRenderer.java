package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import keystrokesmod.event.RenderTickEvent;
import keystrokesmod.event.TickEvent;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class MixinGameRenderer {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(net.minecraft.class_3695 profiler, float tickDelta, long startTime, boolean renderBlockOutline, CallbackInfo ci) {
        Raven.EVENT_BUS.post(new RenderTickEvent(TickEvent.Phase.START, tickDelta));
    }
}
