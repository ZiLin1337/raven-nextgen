package keystrokesmod.mixin.impl.render;

import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4603.class)
public class MixinInGameOverlayRenderer {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void onRenderFireOverlay(
        net.minecraft.class_4587 matrices,
        net.minecraft.class_4597 vertexConsumers,
        float tickDelta,
        CallbackInfo ci) {
        // NoRender模块 - 火焰覆盖
    }
}
