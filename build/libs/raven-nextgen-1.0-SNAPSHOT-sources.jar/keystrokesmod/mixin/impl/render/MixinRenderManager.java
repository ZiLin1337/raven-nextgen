package keystrokesmod.mixin.impl.render;

import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_898.class)
public class MixinRenderManager {
}
