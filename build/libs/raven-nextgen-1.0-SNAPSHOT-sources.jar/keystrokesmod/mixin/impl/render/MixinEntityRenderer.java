package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import keystrokesmod.event.WorldRenderEvent;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class MixinEntityRenderer {

    @Shadow @Final private class_310 client;

    @Inject(method = "renderWorld", at = @At(value = "FIELD",
            target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z",
            opcode = Opcodes.GETFIELD, ordinal = 0))
    private void onRenderWorld(class_9779 tickCounter, CallbackInfo ci) {
        Raven.EVENT_BUS.post(new WorldRenderEvent(tickCounter.method_60637(false)));
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void onHurtCam(class_4587 matrixStack, float f, CallbackInfo ci) {
        // NoHurtCam will cancel this
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void onBobView(class_4587 matrixStack, float f, CallbackInfo ci) {
        // NoBob will cancel this
    }

    @Inject(method = "renderHand", at = @At("HEAD"))
    private void onRenderHand(class_4184 camera, float tickDelta, Matrix4f matrix4f, CallbackInfo ci) {
        // ItemRender hook for future use
    }
}
