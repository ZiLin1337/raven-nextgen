package keystrokesmod.mixin.impl.render;

import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_425.class)
public class MixinSplashOverlay {
    // NoLoading - 启动画面
}
