package keystrokesmod.mixin.impl.render;

import net.minecraft.class_978;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_978.class)
public class MixinDeadmau5FeatureRenderer {
    // NameTags - 玩家名标签渲染
}
