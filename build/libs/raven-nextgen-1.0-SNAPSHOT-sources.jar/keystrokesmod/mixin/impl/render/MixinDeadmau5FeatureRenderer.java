package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_978;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_978.class)
public class MixinDeadmau5FeatureRenderer {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        // Deadmau5渲染
        // 可用于NameTags钩子
    }
}
