package keystrokesmod.mixin.impl.render;

import net.minecraft.class_4618;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_4618.class)
public class MixinOutlineVertexConsumerProvider {
    // ESP/Glow - 轮廓渲染
}
