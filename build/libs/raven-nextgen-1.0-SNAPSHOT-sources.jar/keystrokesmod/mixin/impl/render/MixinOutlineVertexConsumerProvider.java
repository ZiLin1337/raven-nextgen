package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_4618;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4618.class)
public class MixinOutlineVertexConsumerProvider {
    @Inject(method = "applyOutlineColor", at = @At("HEAD"))
    private void onApplyOutline(CallbackInfo ci) {
        // 轮廓渲染
        // 可用于ESP/Glow钩子
    }
}
