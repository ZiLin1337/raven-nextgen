package keystrokesmod.mixin.impl.render;

import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_408.class)
public class MixinChatScreen {
}
