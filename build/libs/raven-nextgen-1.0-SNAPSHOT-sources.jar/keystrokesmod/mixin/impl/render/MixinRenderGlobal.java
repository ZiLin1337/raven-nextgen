package keystrokesmod.mixin.impl.render;

import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.render.Freelook;
import net.minecraft.class_1297;
import net.minecraft.class_287;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_287.class)
public class MixinRenderGlobal {
    @Redirect(method = "setupTerrain", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getYaw(F)F"))
    private float redirectSetupTerrainYaw(class_1297 entity, float tickDelta) {
        if (ModuleManager.freelook != null && ModuleManager.freelook.isEnabled()
                && Freelook.perspectiveToggled && entity == class_310.method_1551().method_1560()) {
            return Freelook.cameraYaw;
        }
        return entity.method_5705(tickDelta);
    }

    @Redirect(method = "setupTerrain", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getPitch(F)F"))
    private float redirectSetupTerrainPitch(class_1297 entity, float tickDelta) {
        if (ModuleManager.freelook != null && ModuleManager.freelook.isEnabled()
                && Freelook.perspectiveToggled && entity == class_310.method_1551().method_1560()) {
            return Freelook.cameraPitch;
        }
        return entity.method_5695(tickDelta);
    }
}