package keystrokesmod.mixin.impl.render;

import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_761.class)
public class MixinWorldRenderer {
}
