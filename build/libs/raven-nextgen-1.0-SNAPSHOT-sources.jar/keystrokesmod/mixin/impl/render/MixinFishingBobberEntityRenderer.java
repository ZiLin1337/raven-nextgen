package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_906;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_906.class)
public class MixinFishingBobberEntityRenderer {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        // 鱼漂渲染
        // 可用于AutoFish钩子
    }
}
