package keystrokesmod.mixin.impl.render;

import net.minecraft.class_906;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_906.class)
public class MixinFishingBobberEntityRenderer {
    // ESP - 鱼漂渲染
}
