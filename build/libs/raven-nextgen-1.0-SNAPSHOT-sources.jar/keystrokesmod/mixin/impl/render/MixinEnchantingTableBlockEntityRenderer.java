package keystrokesmod.mixin.impl.render;

import net.minecraft.class_828;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_828.class)
public class MixinEnchantingTableBlockEntityRenderer {
    // StorageESP - 附魔台方块实体渲染
}
