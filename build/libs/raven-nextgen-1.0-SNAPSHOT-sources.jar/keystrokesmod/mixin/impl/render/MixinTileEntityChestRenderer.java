package keystrokesmod.mixin.impl.render;

import org.spongepowered.asm.mixin.Mixin;

// 1.21.4中TileEntityEnderChestRenderer不存在
// 此mixin在Fabric环境下为兼容桩
@Mixin(net.minecraft.class_824.class)
public class MixinTileEntityChestRenderer {
}
