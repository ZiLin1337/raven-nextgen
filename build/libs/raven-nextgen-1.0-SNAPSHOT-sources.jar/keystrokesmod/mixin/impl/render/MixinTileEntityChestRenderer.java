package keystrokesmod.mixin.impl.render;

import net.minecraft.class_826;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_826.class)
public class MixinTileEntityChestRenderer {
}
