package keystrokesmod.mixin.impl.render;

import net.minecraft.class_2586;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import net.minecraft.class_827;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_824.class)
public class MixinTileEntityChestRenderer {

    @Inject(method = "render(Lnet/minecraft/client/render/block/entity/BlockEntityRenderer;Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V", at = @At("HEAD"))
    private static <T extends class_2586> void onRenderHead(
        class_827<T> renderer, T blockEntity, float tickDelta,
        class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        // ChestESP模块钩子
    }

    @Inject(method = "render(Lnet/minecraft/client/render/block/entity/BlockEntityRenderer;Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V", at = @At("TAIL"))
    private static <T extends class_2586> void onRenderTail(
        class_827<T> renderer, T blockEntity, float tickDelta,
        class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        // ChestESP模块钩子
    }
}
