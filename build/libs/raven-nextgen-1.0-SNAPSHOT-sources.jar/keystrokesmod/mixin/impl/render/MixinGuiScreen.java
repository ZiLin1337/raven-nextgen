package keystrokesmod.mixin.impl.render;

import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_437.class)
public class MixinGuiScreen {
}