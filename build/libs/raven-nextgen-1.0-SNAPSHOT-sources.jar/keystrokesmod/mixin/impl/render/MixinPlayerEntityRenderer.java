package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_1007;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class MixinPlayerEntityRenderer {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        // 玩家渲染
        // 可用于ESP钩子
    }
}
