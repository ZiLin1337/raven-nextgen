package keystrokesmod.mixin.impl.render;

import net.minecraft.class_1007;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1007.class)
public class MixinPlayerEntityRenderer {
}
