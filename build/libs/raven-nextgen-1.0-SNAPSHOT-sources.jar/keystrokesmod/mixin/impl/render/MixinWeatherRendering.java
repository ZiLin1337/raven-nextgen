package keystrokesmod.mixin.impl.render;

import net.minecraft.class_9976;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_9976.class)
public class MixinWeatherRendering {
    // Weather - 天气渲染
}
