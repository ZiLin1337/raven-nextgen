package keystrokesmod.mixin.impl.render;

import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_922.class)
public class MixinLivingEntityRenderer {
}
