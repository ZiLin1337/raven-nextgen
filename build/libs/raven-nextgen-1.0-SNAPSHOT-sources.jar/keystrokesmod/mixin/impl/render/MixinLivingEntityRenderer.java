package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_1309;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
public abstract class MixinLivingEntityRenderer {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(class_1309 entity, float yaw, float tickDelta, net.minecraft.class_4597 vertexConsumers, net.minecraft.class_4587 matrices, int light, CallbackInfo ci) {
        // 实体渲染开始事件
        // 可用于ESP/Chams钩子
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void onRenderReturn(class_1309 entity, float yaw, float tickDelta, net.minecraft.class_4597 vertexConsumers, net.minecraft.class_4587 matrices, int light, CallbackInfo ci) {
        // 实体渲染结束事件
    }
}
