package keystrokesmod.mixin.impl.render;

import net.minecraft.class_9978;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_9978.class)
public class MixinWorldBorderRendering {
    // NoRender - 世界边界渲染
}
