package keystrokesmod.mixin.impl.render;

import keystrokesmod.Raven;
import net.minecraft.class_9978;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9978.class)
public class MixinWorldBorderRendering {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(CallbackInfo ci) {
        // 世界边界渲染
        // 可用于NoRender模块
    }
}
