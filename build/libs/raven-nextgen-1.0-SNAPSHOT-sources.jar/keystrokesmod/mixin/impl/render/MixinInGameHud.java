package keystrokesmod.mixin.impl.render;

import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.render.HUD;
import net.minecraft.class_329;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class MixinInGameHud {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHud(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        // Hook for HUD module rendering
    }
}