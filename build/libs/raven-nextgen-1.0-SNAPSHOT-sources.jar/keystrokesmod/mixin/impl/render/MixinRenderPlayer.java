package keystrokesmod.mixin.impl.render;

import net.minecraft.class_1007;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class MixinRenderPlayer {

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
    private void onRenderHead(
        net.minecraft.class_10055 state,
        net.minecraft.class_4587 matrices,
        net.minecraft.class_4597 vertexConsumers,
        int light,
        CallbackInfo ci) {
        // 玩家渲染钩子 - 物品伪造/BlockAnimation模块
    }

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("TAIL"))
    private void onRenderTail(
        net.minecraft.class_10055 state,
        net.minecraft.class_4587 matrices,
        net.minecraft.class_4597 vertexConsumers,
        int light,
        CallbackInfo ci) {
        // 渲染结束钩子
    }
}