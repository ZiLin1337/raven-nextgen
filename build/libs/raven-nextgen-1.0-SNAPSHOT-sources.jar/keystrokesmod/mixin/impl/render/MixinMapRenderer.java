package keystrokesmod.mixin.impl.render;

import net.minecraft.class_330;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_330.class)
public class MixinMapRenderer {
    // MapHack - 地图渲染
}
