package keystrokesmod.mixin.impl.world;

import net.minecraft.class_18;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_18.class)
public class MixinWorldInfo {
}
