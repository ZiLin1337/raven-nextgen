package keystrokesmod.mixin.impl.world;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public class MixinBlock {
    @Inject(method = "getSlipperiness", at = @At("RETURN"), cancellable = true)
    private void onGetSlipperiness(class_2680 state, class_1922 world, class_2338 pos, net.minecraft.class_1297 entity, CallbackInfoReturnable<Float> cir) {
        // 可以添加NoSlow等模块的滑动性修改逻辑
    }

    @Inject(method = "isOpaque", at = @At("RETURN"), cancellable = true)
    private void onIsOpaque(class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        // 可以添加Xray等模块的可见性修改逻辑
    }
}