package keystrokesmod.mixin.impl.world;

import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_638.class)
public class MixinClientWorld {
}
