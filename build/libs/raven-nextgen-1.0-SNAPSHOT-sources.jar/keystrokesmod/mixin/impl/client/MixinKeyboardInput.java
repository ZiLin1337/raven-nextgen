package keystrokesmod.mixin.impl.client;

import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_743.class)
public class MixinKeyboardInput {
    // InventoryMove - 键盘输入
}
