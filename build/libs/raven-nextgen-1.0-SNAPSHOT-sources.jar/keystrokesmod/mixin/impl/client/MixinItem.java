package keystrokesmod.mixin.impl.client;

import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1792.class)
public class MixinItem {
    // ItemESP - 物品基类
}
