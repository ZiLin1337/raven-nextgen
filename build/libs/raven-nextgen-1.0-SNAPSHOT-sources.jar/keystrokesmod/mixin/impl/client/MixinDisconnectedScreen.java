package keystrokesmod.mixin.impl.client;

import net.minecraft.class_419;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_419.class)
public class MixinDisconnectedScreen {
    // AntiDisconnect - 断开连接屏幕
}
