package keystrokesmod.mixin.impl.client;

import keystrokesmod.Raven;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_742.class)
public class MixinAbstractClientPlayerEntity {
    // 抽象客户端玩家实体
    // 可用于Skin/Cape模块
}
