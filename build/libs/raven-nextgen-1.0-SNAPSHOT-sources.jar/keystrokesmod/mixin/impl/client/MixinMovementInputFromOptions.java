package keystrokesmod.mixin.impl.client;

import keystrokesmod.Raven;
import keystrokesmod.event.PostPlayerInputEvent;
import keystrokesmod.event.PrePlayerInputEvent;
import net.minecraft.class_315;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public class MixinMovementInputFromOptions {

    @Shadow @Final private class_315 settings;

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void onTickPre(boolean slowDown, float tickDelta, CallbackInfo ci) {
        class_743 self = (class_743)(Object)this;
        float forward = self.field_54155.comp_3159() ? 1.0F : (self.field_54155.comp_3160() ? -1.0F : 0.0F);
        float strafe = self.field_54155.comp_3161() ? 1.0F : (self.field_54155.comp_3162() ? -1.0F : 0.0F);
        boolean jump = self.field_54155.comp_3163();
        boolean sneak = self.field_54155.comp_3164();

        PrePlayerInputEvent event = new PrePlayerInputEvent(forward, strafe, jump, sneak, slowDown ? 0.3D : 1.0D);
        Raven.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void onTickPost(boolean slowDown, float tickDelta, CallbackInfo ci) {
        class_743 self = (class_743)(Object)this;
        Raven.EVENT_BUS.post(new PostPlayerInputEvent(
            self.field_54155.comp_3159() ? 1.0F : (self.field_54155.comp_3160() ? -1.0F : 0.0F),
            self.field_54155.comp_3161() ? 1.0F : (self.field_54155.comp_3162() ? -1.0F : 0.0F),
            self.field_54155.comp_3163(),
            self.field_54155.comp_3164(),
            slowDown ? 0.3D : 1.0D
        ));
    }
}