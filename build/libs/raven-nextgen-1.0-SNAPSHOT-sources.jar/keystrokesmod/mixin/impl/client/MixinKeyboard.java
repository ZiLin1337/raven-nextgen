package keystrokesmod.mixin.impl.client;

import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_309.class)
public class MixinKeyboard {
    // AutoWalk - 键盘事件
}
