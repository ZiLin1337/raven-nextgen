package keystrokesmod.mixin.impl.client;

import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_312.class)
public class MixinMouse {
    // CameraClip - 鼠标输入
}
