package keystrokesmod.mixin.impl.client;

import net.minecraft.class_304;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_304.class)
public class MixinKeyBinding {
    // AutoWalk - 按键绑定
}
