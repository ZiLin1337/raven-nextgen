package keystrokesmod.mixin.impl.client;

import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_759.class)
public class MixinHeldItemRenderer {
    // 手持物品渲染
}
