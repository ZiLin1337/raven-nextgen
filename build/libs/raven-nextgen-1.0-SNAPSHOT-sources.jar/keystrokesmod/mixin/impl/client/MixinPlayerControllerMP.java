package keystrokesmod.mixin.impl.client;

import keystrokesmod.Raven;
import keystrokesmod.event.*;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_636;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class MixinPlayerControllerMP {
    @Shadow private int blockBreakingCooldown;

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void injectAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        Raven.EVENT_BUS.post(new PreAttackEvent(null));
    }

    @Inject(method = "attackEntity", at = @At("RETURN"))
    private void onPostAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        Raven.EVENT_BUS.post(new PostAttackEvent(target));
    }

    @Redirect(
        method = "updateBlockBreakingProgress",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/block/BlockState;calcBlockBreakingDelta(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;)F"
        )
    )
    private float fastMineScaleHardness(class_2680 state, class_1657 player, net.minecraft.class_1922 world, class_2338 pos) {
        float hardness = state.method_26165(player, world, pos);
        return hardness;
    }

    @Unique
    private void raven$fastMineApplyBreakDelaySlider() {
        // FastMine delay override - will restore when module is available
    }

    @Inject(
        method = "attackBlock",
        at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;blockBreakingCooldown:I", ordinal = 0, shift = At.Shift.AFTER)
    )
    private void raven$fastMineAfterClickBlockSetDelay(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        raven$fastMineApplyBreakDelaySlider();
    }

    @Inject(
        method = "updateBlockBreakingProgress",
        at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;blockBreakingCooldown:I", ordinal = 0, shift = At.Shift.AFTER)
    )
    private void raven$fastMineAfterCreativeMiningSetDelay(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        raven$fastMineApplyBreakDelaySlider();
    }
}
