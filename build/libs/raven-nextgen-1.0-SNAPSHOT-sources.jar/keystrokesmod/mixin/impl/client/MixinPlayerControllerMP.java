package keystrokesmod.mixin.impl.client;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class MixinPlayerControllerMP {
    private static final class_310 mc = class_310.method_1551();

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void onAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) { }

    @Inject(method = "attackEntity", at = @At("RETURN"))
    private void onPostAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) { }
}
