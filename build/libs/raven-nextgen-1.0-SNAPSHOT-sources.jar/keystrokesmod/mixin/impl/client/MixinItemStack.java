package keystrokesmod.mixin.impl.client;

import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1799.class)
public class MixinItemStack {
}
