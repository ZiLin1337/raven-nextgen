package keystrokesmod.mixin.impl.client;

import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_744.class)
public class MixinInput {
    // 输入基类
}
