package keystrokesmod.mixin.impl.client;

import net.minecraft.class_434;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_434.class)
public class MixinDownloadingTerrainScreen {
    // NoLoading - 下载地形屏幕
}
