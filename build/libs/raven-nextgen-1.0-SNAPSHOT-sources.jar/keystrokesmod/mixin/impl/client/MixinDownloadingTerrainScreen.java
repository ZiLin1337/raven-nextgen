package keystrokesmod.mixin.impl.client;

import keystrokesmod.Raven;
import net.minecraft.class_434;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_434.class)
public class MixinDownloadingTerrainScreen {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(CallbackInfo ci) {
        // 下载地形渲染
        // 可用于NoLoading模块
    }
}
