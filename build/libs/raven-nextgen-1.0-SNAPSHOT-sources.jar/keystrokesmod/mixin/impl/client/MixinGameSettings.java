package keystrokesmod.mixin.impl.client;

import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.player.SafeWalk;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(class_315.class)
public class MixinGameSettings {
    @Overwrite
    public static boolean isKeyPressed(class_304 key) {
        class_310 mc = class_310.method_1551();
        SafeWalk safewalk = ModuleManager.safeWalk;
        if (key == mc.field_1690.field_1832 && safewalk != null && safewalk.isEnabled() && safewalk.sneak.isToggled() && safewalk.isSneaking) {
            return true;
        }
        return key.method_1434();
    }
}