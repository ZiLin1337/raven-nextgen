package keystrokesmod.mixin.impl.client;

import net.minecraft.class_315;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_315.class)
public class MixinGameSettings {
}
