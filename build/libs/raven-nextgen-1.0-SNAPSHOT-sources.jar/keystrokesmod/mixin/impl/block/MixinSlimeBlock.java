package keystrokesmod.mixin.impl.block;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2490;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2490.class)
public class MixinSlimeBlock {
    @Inject(method = "bounce", at = @At("HEAD"), cancellable = true)
    private void onBounce(class_1297 entity, CallbackInfo ci) {
        // NoSlow - 史莱姆块弹跳钩子
    }

    @Inject(method = "onSteppedOn", at = @At("HEAD"), cancellable = true)
    private void onSteppedOn(class_1937 world, class_2338 pos, class_2680 state, class_1297 entity, CallbackInfo ci) {
        // NoSlow - 史莱姆块减速钩子
    }
}
