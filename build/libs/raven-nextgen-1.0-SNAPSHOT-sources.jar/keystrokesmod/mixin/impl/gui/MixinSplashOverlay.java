package keystrokesmod.mixin.impl.gui;

import keystrokesmod.Raven;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_425.class)
public class MixinSplashOverlay {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(CallbackInfo ci) {
        // 启动画面渲染
        // 可用于NoLoading模块
    }
}
