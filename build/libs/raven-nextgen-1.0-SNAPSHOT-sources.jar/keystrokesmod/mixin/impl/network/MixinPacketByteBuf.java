package keystrokesmod.mixin.impl.network;

import net.minecraft.class_2540;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2540.class)
public class MixinPacketByteBuf {
    // 网络包缓冲区
}
