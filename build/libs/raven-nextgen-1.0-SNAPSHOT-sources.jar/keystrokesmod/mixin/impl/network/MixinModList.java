package keystrokesmod.mixin.impl.network;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(net.minecraft.class_2535.class)
public class MixinModList {
}
