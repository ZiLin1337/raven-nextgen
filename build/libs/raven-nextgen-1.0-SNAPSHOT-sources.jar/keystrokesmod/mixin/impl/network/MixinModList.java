package keystrokesmod.mixin.impl.network;

import net.minecraft.class_2535;
import org.spongepowered.asm.mixin.Mixin;

// 1.21.4中ModList工作方式已变化，保留为骨架
@Mixin(class_2535.class)
public class MixinModList {
}
