package keystrokesmod.mixin.impl.network;

import keystrokesmod.utility.ServerUtils;
import net.minecraft.class_2749;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class MixinClientPlayNetworkHandler {
    @Inject(method = "onGameMessage", at = @At("HEAD"))
    private void onGameMessage(CallbackInfo ci) {
        // 游戏消息
        // 可用于ChatFilter模块
    }
    
    @Inject(method = "onHealthUpdate", at = @At("RETURN"))
    private void onHealthUpdate(class_2749 packet, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            ServerUtils.onHealthUpdate(packet.method_11833(), packet.method_11831(), packet.method_11834());
        }
    }
}
