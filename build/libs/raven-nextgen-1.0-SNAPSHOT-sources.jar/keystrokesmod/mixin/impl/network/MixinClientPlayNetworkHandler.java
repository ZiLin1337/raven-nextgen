package keystrokesmod.mixin.impl.network;

import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_634.class)
public class MixinClientPlayNetworkHandler {
}