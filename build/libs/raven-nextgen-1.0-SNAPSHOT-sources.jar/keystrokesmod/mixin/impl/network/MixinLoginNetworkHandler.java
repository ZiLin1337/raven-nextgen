package keystrokesmod.mixin.impl.network;

import net.minecraft.class_635;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_635.class)
public class MixinLoginNetworkHandler {
}
