package keystrokesmod.mixin.impl.network;

import keystrokesmod.Raven;
import keystrokesmod.event.PreEntityVelocityEvent;
import keystrokesmod.event.PreExplosionPacketEvent;
import keystrokesmod.module.ModuleManager;
import net.minecraft.class_2664;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class MixinNetHandlerPlayClient {

    @Inject(method = "onPlayerPositionLook", at = @At("HEAD"))
    public void onPlayerPositionLookPre(class_2708 packet, CallbackInfo ci) {
        if (ModuleManager.noRotate != null) {
            ModuleManager.noRotate.onPlayerPositionLookPre();
        }
    }

    @Inject(method = "onPlayerPositionLook", at = @At("RETURN"))
    public void onPlayerPositionLook(class_2708 packet, CallbackInfo ci) {
        if (ModuleManager.noRotate != null) {
            ModuleManager.noRotate.onPlayerPositionLook(packet);
        }
    }

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    public void onEntityVelocityUpdate(class_2743 packet, CallbackInfo ci) {
        PreEntityVelocityEvent event = new PreEntityVelocityEvent(packet);
        Raven.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "onExplosion", at = @At("HEAD"), cancellable = true)
    public void onExplosion(class_2664 packet, CallbackInfo ci) {
        PreExplosionPacketEvent event = new PreExplosionPacketEvent(packet);
        Raven.EVENT_BUS.post(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}