package keystrokesmod.mixin.impl.network;

import net.minecraft.class_2716;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2716.class)
public class MixinEntitiesDestroyS2CPacket {
    // Velocity/VelocityFix - 实体销毁包
}
