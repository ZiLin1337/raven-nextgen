package keystrokesmod.mixin.impl.network;

import net.minecraft.class_2886;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2886.class)
public class MixinPlayerInteractItemC2SPacket {
    // KillAura/Reach - 玩家交互物品包
}
