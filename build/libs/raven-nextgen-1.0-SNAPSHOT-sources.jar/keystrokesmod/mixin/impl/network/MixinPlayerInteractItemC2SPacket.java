package keystrokesmod.mixin.impl.network;

import keystrokesmod.Raven;
import net.minecraft.class_2886;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2886.class)
public class MixinPlayerInteractItemC2SPacket {
    @Inject(method = "getHand", at = @At("HEAD"))
    private void onGetHand(CallbackInfo ci) {
        // 获取交互手
        // 可用于KillAura模块
    }
}
