package keystrokesmod.mixin.impl.network;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(net.minecraft.class_634.class)
public class MixinMessageHandler {
}
