package keystrokesmod.mixin.impl.network;

import keystrokesmod.Raven;
import net.minecraft.class_635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_635.class)
public class MixinClientLoginNetworkHandler {
    @Inject(method = "onLoginSuccess", at = @At("HEAD"))
    private void onLoginSuccess(CallbackInfo ci) {
        // 登录成功
    }
}
