package keystrokesmod.mixin.impl.network;

import net.minecraft.class_8673;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_8673.class)
public class MixinCommonNetworkHandler {
}
