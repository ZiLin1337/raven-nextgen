package keystrokesmod.mixin.impl.network;

import net.minecraft.class_1723;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1723.class)
public class MixinPlayerInventory {
}
