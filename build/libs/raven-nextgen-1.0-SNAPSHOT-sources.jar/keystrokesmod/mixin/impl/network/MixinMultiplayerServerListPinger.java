package keystrokesmod.mixin.impl.network;

import net.minecraft.class_644;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_644.class)
public class MixinMultiplayerServerListPinger {
    // PingSpoof - 服务器列表Ping
}
