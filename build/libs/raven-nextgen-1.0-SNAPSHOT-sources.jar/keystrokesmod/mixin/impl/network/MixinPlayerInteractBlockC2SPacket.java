package keystrokesmod.mixin.impl.network;

import net.minecraft.class_2885;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2885.class)
public class MixinPlayerInteractBlockC2SPacket {
    // KillAura/Reach - 玩家交互方块包
}
