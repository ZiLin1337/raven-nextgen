package keystrokesmod.mixin.impl.network;

import net.minecraft.class_2889;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2889.class)
public class MixinHandshakeC2SPacket {
    // AntiStaff - 握手包
}
