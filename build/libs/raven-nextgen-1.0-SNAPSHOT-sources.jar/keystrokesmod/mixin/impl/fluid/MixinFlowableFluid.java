package keystrokesmod.mixin.impl.fluid;

import net.minecraft.class_3609;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3609.class)
public class MixinFlowableFluid {
    // Jesus - 流体行走钩子
}
