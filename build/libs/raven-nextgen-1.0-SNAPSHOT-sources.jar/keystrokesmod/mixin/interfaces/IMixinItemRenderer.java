package keystrokesmod.mixin.interfaces;

import net.minecraft.class_1799;

public interface IMixinItemRenderer {
    default void setEquippedProgressMainHand(float progress) {}
    default float getEquippedProgressMainHand() { return 0.0F; }
    default void setEquippedProgressOffHand(float progress) {}
    default float getEquippedProgressOffHand() { return 0.0F; }
    default void setStackToRenderMainHand(class_1799 stack) {}
    default void setStackToRenderOffHand(class_1799 stack) {}
    default void setCancelUpdate(boolean cancelUpdate) {}
    default void setCancelReset(boolean cancelReset) {}
    default boolean isItemRendererInUse() { return false; }
    default void setItemRendererInUse(boolean inUse) {}
}
