package keystrokesmod.lag.handler;

import net.minecraft.class_2596;
import org.jetbrains.annotations.NotNull;

public abstract class AbstractFastTrackProvider {

    public abstract void forPacket(final @NotNull class_2596<?> packet);

}