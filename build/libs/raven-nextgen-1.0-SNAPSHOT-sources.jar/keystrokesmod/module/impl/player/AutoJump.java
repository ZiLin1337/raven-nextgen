package keystrokesmod.module.impl.player;

import keystrokesmod.Raven;
import keystrokesmod.event.PreMotionEvent;
import keystrokesmod.module.Module;
import keystrokesmod.utility.Utils;
import meteordevelopment.orbit.EventHandler;

public class AutoJump extends Module {
    public AutoJump() { super("AutoJump", category.player); }

    @EventHandler
    public void onPreMotion(PreMotionEvent e) {
        if (mc.field_1724 != null && mc.field_1724.method_24828() && Utils.isMoving()) {
            mc.field_1724.method_6043();
        }
    }
}
