package keystrokesmod.module.impl.player;

import keystrokesmod.module.Module;
import net.minecraft.class_2708;

public class NoRotate extends Module {
    public NoRotate() {
        super("NoRotate", Module.category.render);
    }
    
    public void onPlayerPositionLookPre() {
    }
    
    public void onPlayerPositionLook(class_2708 packet) {
    }
}
