package keystrokesmod.module.impl.fun;

import keystrokesmod.Raven;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import net.minecraft.class_2398;

public class FlameTrail extends Module {
    public FlameTrail() { super("FlameTrail", category.fun); }

    public void onUpdate() {
        if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1724.field_6012 % 2 == 0) {
            mc.field_1687.method_8406(class_2398.field_11240, mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), 0, 0, 0);
        }
    }
}
