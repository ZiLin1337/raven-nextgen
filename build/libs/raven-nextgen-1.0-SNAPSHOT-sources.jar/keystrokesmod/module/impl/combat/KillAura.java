package keystrokesmod.module.impl.combat;

import keystrokesmod.module.Module;
import net.minecraft.class_1309;

public class KillAura extends Module {
    public static class_1309 target;
    public static class_1309 attackingEntity;

    public KillAura() {
        super("KillAura", category.combat);
    }
}
