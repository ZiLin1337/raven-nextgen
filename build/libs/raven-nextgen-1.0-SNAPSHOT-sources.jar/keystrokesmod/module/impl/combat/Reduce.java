package keystrokesmod.module.impl.combat;

import keystrokesmod.Raven;
// 
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.SliderSetting;
import meteordevelopment.orbit.EventHandler;

public class Reduce extends Module {
    public SliderSetting horizontal, vertical;

    public Reduce() {
        super("Reduce", category.combat);
        this.registerSetting(horizontal = new SliderSetting("Horizontal", 50, 0, 100, 1));
        this.registerSetting(vertical = new SliderSetting("Vertical", 50, 0, 100, 1));
    }

    @EventHandler
    // TODO: Replace PreKnockbackEvent
    public void onKnockback(Object e) {
        double h = (100.0 - horizontal.getInput()) / 100.0;
        double v = (100.0 - vertical.getInput()) / 100.0;
        // TODO: getHorizontal not available on 1.21.4 event
        // TODO: getVertical not available on 1.21.4 event
    }
}
