package keystrokesmod.module.impl.combat;

import keystrokesmod.Raven;
import keystrokesmod.event.PreMotionEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.RotationUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import java.util.Comparator;

public class TPAura extends Module {
    private SliderSetting range, cps;
    private class_1309 target;

    public TPAura() {
        super("TPAura", category.combat);
        this.registerSetting(range = new SliderSetting("Range", 6, 2, 15, 0.5));
        this.registerSetting(cps = new SliderSetting("CPS", 8, 1, 20, 1));
    }

    @EventHandler
    public void onPreMotion(PreMotionEvent e) {
        if (mc.field_1687 == null) return;
        target = mc.field_1687.method_8390(class_1309.class, mc.field_1724.method_5829().method_1014(range.getInput()),
                e2 -> e2 != mc.field_1724 && e2.method_5805() && e2 instanceof class_1657)
                .stream().min(Comparator.comparingDouble(e2 -> mc.field_1724.method_5739(e2))).orElse(null);
        if (target == null) return;
        float[] rots = RotationUtils.getRotations(target);
        e.setYaw(rots[0]);
        e.setPitch(rots[1]);
        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);
    }
}
