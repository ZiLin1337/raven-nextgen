package keystrokesmod.module.impl.render;

import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.*;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import java.awt.Color;

public class Chams extends Module {
    private static final class_310 mc = class_310.method_1551();
    private SliderSetting mode;
    private ColorSetting color;
    private ButtonSetting invisible;
    private ButtonSetting playersOnly;
    private String[] modes = {"Normal", "Colored", "Textured"};

    public Chams() {
        super("Chams", category.render);
        registerSetting(mode = new SliderSetting("Mode", 0, modes));
        registerSetting(color = new ColorSetting("Color", 255, 85, 255));
        registerSetting(invisible = new ButtonSetting("Invisible players", true));
        registerSetting(playersOnly = new ButtonSetting("Players only", false));
    }

    public static boolean shouldRender(class_1657 player) {
        return player != null && player.method_5805() && !player.method_31481();
    }

    public static int getColor() {
        return new Color(255, 85, 255, 100).getRGB();
    }
}
