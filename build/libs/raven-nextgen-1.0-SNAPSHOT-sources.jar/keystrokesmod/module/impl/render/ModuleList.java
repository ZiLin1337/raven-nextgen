package keystrokesmod.module.impl.render;

import keystrokesmod.Raven;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.setting.impl.SliderSetting;
import net.minecraft.class_327;
import net.minecraft.class_332;
import java.util.Comparator;

public class ModuleList extends Module {
    private SliderSetting x, y, gap;

    public ModuleList() {
        super("ModuleList", category.render);
        this.registerSetting(x = new SliderSetting("X", 2, 0, mc.method_22683().method_4486(), 1));
        this.registerSetting(y = new SliderSetting("Y", 30, 0, mc.method_22683().method_4502(), 1));
        this.registerSetting(gap = new SliderSetting("Gap", 10, 2, 20, 1));
    }

    public void onRenderOverlay(class_332 context) {
        class_327 tr = mc.field_1772;
        java.util.List<Module> enabled = Raven.moduleManager.getModules().stream()
                .filter(m -> m.isEnabled() && !m.moduleCategory().equals(Module.category.client))
                .sorted(Comparator.comparing(m -> -tr.method_1727(m.getName()))).toList();
        int yPos = (int) y.getInput();
        int xPos = (int) x.getInput();
        for (Module m : enabled) {
            int color = keystrokesmod.utility.Utils.getChroma(2L, System.currentTimeMillis() / 50);
            context.method_51433(tr, m.getName(), xPos, yPos, color, true);
            yPos += gap.getInput();
        }
    }
}
