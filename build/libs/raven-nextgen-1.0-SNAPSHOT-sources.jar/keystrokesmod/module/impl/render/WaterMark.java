package keystrokesmod.module.impl.render;

import keystrokesmod.Raven;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.SliderSetting;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class WaterMark extends Module {
    private SliderSetting x, y;

    public WaterMark() {
        super("WaterMark", category.render);
        this.registerSetting(x = new SliderSetting("X", 2, 0, mc.method_22683().method_4486(), 1));
        this.registerSetting(y = new SliderSetting("Y", 2, 0, mc.method_22683().method_4502(), 1));
    }

    public void onRenderOverlay(class_332 context) {
        class_327 tr = mc.field_1772;
        String text = "Raven NextGen [1.21.4]";
        context.method_51433(tr, text, (int)x.getInput(), (int)y.getInput(), 0xFF00FF00, true);
    }
}
