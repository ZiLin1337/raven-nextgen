package keystrokesmod.module.impl.render;

import keystrokesmod.module.Module;
import net.minecraft.class_1309;

public class MobESP extends Module {
    public static boolean renderingOutlinePass = false;

    public MobESP() {
        super("MobESP", category.render);
    }

    public static void onRenderMobPre(class_1309 entity) {
    }

    public static void onRenderMobPost() {
    }
}