package keystrokesmod.module.impl.world;

import keystrokesmod.module.Module;
import net.minecraft.class_1297;

public class AntiBot extends Module {
    public AntiBot() {
        super("Anti Bot", Module.category.world, 0);
    }

    public static boolean isBot(class_1297 entity) {
        return false;
    }
}