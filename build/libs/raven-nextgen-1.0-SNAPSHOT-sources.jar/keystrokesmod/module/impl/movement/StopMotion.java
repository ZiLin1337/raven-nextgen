package keystrokesmod.module.impl.movement;

import keystrokesmod.Raven;
import keystrokesmod.event.PreMotionEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import meteordevelopment.orbit.EventHandler;

public class StopMotion extends Module {
    private ButtonSetting onDisableOnly;

    public StopMotion() {
        super("StopMotion", category.movement);
        this.registerSetting(onDisableOnly = new ButtonSetting("On disable only", false));
    }

    @EventHandler
    public void onPreMotion(PreMotionEvent e) {
        if (onDisableOnly.isToggled()) return;
        if (mc.field_1724 != null) mc.field_1724.method_18800(0, mc.field_1724.method_18798().field_1351, 0);
    }

    public void onDisable() {
        if (mc.field_1724 != null) mc.field_1724.method_18800(0, 0, 0);
    }
}
