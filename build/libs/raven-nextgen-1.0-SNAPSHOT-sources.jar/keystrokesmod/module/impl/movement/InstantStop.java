package keystrokesmod.module.impl.movement;

import keystrokesmod.Raven;
import keystrokesmod.event.PreMotionEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import meteordevelopment.orbit.EventHandler;

public class InstantStop extends Module {
    private ButtonSetting stopOnRelease;

    public InstantStop() {
        super("InstantStop", category.movement);
        this.registerSetting(stopOnRelease = new ButtonSetting("Stop on release", true));
    }

    @EventHandler
    public void onPreMotion(PreMotionEvent e) {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.field_3913.field_3905 == 0 && mc.field_1724.field_3913.field_3907 == 0) {
            mc.field_1724.method_18800(0, mc.field_1724.method_18798().field_1351, 0);
        }
    }
}
