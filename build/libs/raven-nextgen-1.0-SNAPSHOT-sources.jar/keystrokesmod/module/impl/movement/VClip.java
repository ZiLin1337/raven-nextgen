package keystrokesmod.module.impl.movement;

import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;

public class VClip extends Module {
    private SliderSetting distance;
    private ButtonSetting sendMessage;

    public VClip() {
        super("VClip", category.movement, 0);
        this.registerSetting(distance = new SliderSetting("Distance", 3.0, -20.0, 20.0, 0.5));
        this.registerSetting(sendMessage = new ButtonSetting("Send message", true));
    }

    public void onEnable() {
        double distance = this.distance.getInput();
        if (this.distance.getInput() != 0.0D) {
            mc.field_1724.method_5814(mc.field_1724.method_23317(), mc.field_1724.method_23318() + distance, mc.field_1724.method_23321());
            if (sendMessage.isToggled()) {
                Utils.sendMessage("&7Teleported you " + ((distance > 0.0) ? "upwards" : "downwards") + " by &b" + distance + " &7blocks.");
            }
        }

        this.disable();
    }
}
