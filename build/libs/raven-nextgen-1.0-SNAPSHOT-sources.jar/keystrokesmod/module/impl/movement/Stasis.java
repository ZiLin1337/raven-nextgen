package keystrokesmod.module.impl.movement;

import keystrokesmod.Raven;
import keystrokesmod.event.PreMotionEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import meteordevelopment.orbit.EventHandler;

public class Stasis extends Module {
    private ButtonSetting freezeX, freezeY, freezeZ;
    private double savedX, savedY, savedZ;

    public Stasis() {
        super("Stasis", category.movement);
        this.registerSetting(freezeX = new ButtonSetting("Freeze X", true));
        this.registerSetting(freezeY = new ButtonSetting("Freeze Y", false));
        this.registerSetting(freezeZ = new ButtonSetting("Freeze Z", true));
    }

    public void onEnable() {
        if (mc.field_1724 != null) {
            savedX = mc.field_1724.method_23317();
            savedY = mc.field_1724.method_23318();
            savedZ = mc.field_1724.method_23321();
        }
    }

    @EventHandler
    public void onPreMotion(PreMotionEvent e) {
        if (mc.field_1724 == null) return;
        double x = freezeX.isToggled() ? savedX : mc.field_1724.method_23317();
        double y = freezeY.isToggled() ? savedY : mc.field_1724.method_23318();
        double z = freezeZ.isToggled() ? savedZ : mc.field_1724.method_23321();
        mc.field_1724.method_18800(0, 0, 0);
        mc.field_1724.method_5814(x, y, z);
    }
}
