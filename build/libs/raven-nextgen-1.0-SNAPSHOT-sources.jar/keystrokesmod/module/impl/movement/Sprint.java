package keystrokesmod.module.impl.movement;

import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import net.minecraft.class_1294;

public class Sprint extends Module {
    public SliderSetting mode;
    private ButtonSetting blindJump;
    private static final String[] MODES = new String[]{"Vanilla", "Omni"};

    public Sprint() {
        super("Sprint", category.movement);
        this.registerSetting(mode = new SliderSetting("Mode", 0, MODES));
        this.registerSetting(blindJump = new ButtonSetting("Blind jump", false));
    }

    @Override
    public String getInfo() {
        return MODES[(int) mode.getInput()];
    }

    @Override
    public void onUpdate() {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.method_6059(class_1294.field_5919) && !blindJump.isToggled()) {
            mc.field_1724.method_5728(false);
            return;
        }
        if (mode.getInput() == 1) {
            mc.field_1724.method_5728(true);
            return;
        }
        if (mc.field_1724.field_3913.field_3905 > 0) {
            mc.field_1724.method_5728(true);
        } else {
            mc.field_1724.method_5728(false);
        }
    }
}