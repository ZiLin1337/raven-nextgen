package keystrokesmod.clickgui;

import keystrokesmod.Raven;
import keystrokesmod.clickgui.components.impl.CategoryComponent;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.utility.Utils;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ClickGui extends class_437 {
    public static ArrayList<CategoryComponent> categories;
    private CategoryComponent draggedCategory;
    private static boolean isInitialized;

    public ClickGui() {
        super(class_2561.method_43470("Raven ClickGUI"));
        categories = new ArrayList<>();
    }

    private void initCategories() {
        if (isInitialized) return;
        isInitialized = true;
        categories.clear();
        
        int x = 5;
        int y = 5;
        for (Module.category c : Module.category.values()) {
            CategoryComponent categoryComponent = new CategoryComponent(c);
            categoryComponent.x = x;
            categoryComponent.y = y;
            categories.add(categoryComponent);
            x += 105;
            if (x + 100 > field_22789) {
                x = 5;
                y += 20;
            }
        }
        
        // Reload profiles and scripts categories
        for (CategoryComponent categoryComponent : categories) {
            if (categoryComponent.category == Module.category.profiles) {
                categoryComponent.reloadModules(true);
            } else if (categoryComponent.category == Module.category.scripts) {
                categoryComponent.reloadModules(false);
            }
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        initCategories();
        
        // Semi-transparent background
        context.method_25294(0, 0, field_22789, field_22790, 0x80000000);
        
        // Draw watermark
        String watermark = "Raven bS [1.21.4]";
        int wmColor = Utils.getChroma(2L, 0L);
        context.method_25303(field_22793, watermark, 2, 2, wmColor);
        
        // Render categories (sorted by last interaction for Z-ordering)
        List<CategoryComponent> sorted = new ArrayList<>(categories);
        sorted.sort(Comparator.comparingLong(c -> c.lastInteractedTime));
        
        for (CategoryComponent category : sorted) {
            category.render(context, mouseX, mouseY);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int mx = (int) mouseX;
        int my = (int) mouseY;
        
        // Find topmost category under cursor
        List<CategoryComponent> sorted = new ArrayList<>(categories);
        sorted.sort((a, b) -> Long.compare(b.lastInteractedTime, a.lastInteractedTime));
        
        for (CategoryComponent category : sorted) {
            if (category.isMouseOver(mx, my)) {
                category.onClick(mx, my, button);
                draggedCategory = category.dragging ? category : null;
                break;
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (draggedCategory != null) {
            draggedCategory.onMouseRelease();
            draggedCategory = null;
        }
        for (CategoryComponent category : categories) {
            category.onMouseRelease();
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        int mx = (int) mouseX;
        int my = (int) mouseY;
        
        for (CategoryComponent category : categories) {
            category.onMouseMove(mx, my);
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int mx = (int) mouseX;
        int my = (int) mouseY;
        // Handle scroll for categories
        for (CategoryComponent category : categories) {
            if (category.isMouseOver(mx, my)) {
                category.onScroll((int) verticalAmount);
                break;
            }
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        return super.method_25400(chr, modifiers);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC
            method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25419() {
        for (CategoryComponent c : categories) {
            c.onMouseRelease();
        }
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    /**
     * Reload modules in each category
     */
    public void reloadModules() {
        if (categories != null) {
            for (CategoryComponent category : categories) {
                if (category.category == Module.category.profiles) {
                    category.reloadModules(true);
                } else if (category.category == Module.category.scripts) {
                    category.reloadModules(false);
                } else {
                    category.reloadModules();
                }
            }
        }
    }

    /**
     * Force reinitialize GUI
     */
    public void forceReinit() {
        isInitialized = false;
    }

    public static double getActiveRenderScale() {
        return keystrokesmod.module.impl.client.Gui.getGuiScale();
    }
}
