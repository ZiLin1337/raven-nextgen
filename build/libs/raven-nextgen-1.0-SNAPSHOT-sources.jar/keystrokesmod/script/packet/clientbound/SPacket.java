package keystrokesmod.script.packet.clientbound;

import net.minecraft.class_2596;

public class SPacket {
    public class_2596<?> packet;
    public SPacket() {
    }
}
