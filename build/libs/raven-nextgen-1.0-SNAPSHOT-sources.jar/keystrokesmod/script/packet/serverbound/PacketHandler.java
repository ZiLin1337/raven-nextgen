package keystrokesmod.script.packet.serverbound;

import net.minecraft.class_2596;

public class PacketHandler {
    public static class_2596<?> convertCPacket(CPacket packet) {
        return null;
    }
}
