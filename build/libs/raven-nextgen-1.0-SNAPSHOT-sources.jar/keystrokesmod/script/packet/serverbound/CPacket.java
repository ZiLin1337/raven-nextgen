package keystrokesmod.script.packet.serverbound;

import net.minecraft.class_2596;

public class CPacket {
    public class_2596<?> packet;
    public CPacket() {
    }
}
