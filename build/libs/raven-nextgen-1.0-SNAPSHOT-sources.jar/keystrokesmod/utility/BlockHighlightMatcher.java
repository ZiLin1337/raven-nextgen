package keystrokesmod.utility;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface BlockHighlightMatcher {

    boolean matchesBlock(class_2680 state);

    default boolean shouldIndexAt(class_2338 pos, class_2680 state) {
        return matchesBlock(state);
    }

    default boolean isActive() {
        return true;
    }

    default void beginScanPass() {
    }
}
