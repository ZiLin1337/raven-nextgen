package keystrokesmod.utility;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3965;
import net.minecraft.class_419;
import net.minecraft.class_640;
import net.minecraft.class_9334;
import net.minecraft.util.math.*;
import java.util.*;
import java.util.stream.Collectors;

public class Utils implements IMinecraftInstance {
    public static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger("Raven");
    public static List<String> friends = new ArrayList<>();
    public static List<String> enemies = new ArrayList<>();
    public static HashSet<String> friendsSet = new HashSet<>();
    public static HashSet<String> enemiesSet = new HashSet<>();

    // ==================== 消息工具 ====================
    public static void sendMessage(String message) {
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470(message), false);
    }

    public static void sendRawMessage(String message) {
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470(message), false);
    }

    // ==================== 移动工具 ====================
    public static boolean isMoving() {
        return mc.field_1724 != null && (mc.field_1724.field_3913.field_3905 != 0 || mc.field_1724.field_3913.field_3907 != 0);
    }

    public static boolean isDiagonal(boolean checkMoving) {
        if (mc.field_1724 == null) return false;
        boolean forward = mc.field_1724.field_3913.field_3905 != 0;
        boolean sideways = mc.field_1724.field_3913.field_3907 != 0;
        return forward && sideways;
    }

    public static void setSpeed(double speed) {
        if (mc.field_1724 == null) return;
        float yaw = mc.field_1724.method_36454();
        float forward = 1.0F;
        float strafe = 0.0F;
        if (mc.field_1724.field_3913.field_3905 < 0) {
            yaw += 180;
            forward = -1.0F;
        }
        if (mc.field_1724.field_3913.field_3907 > 0.0F) yaw += 90.0F * forward;
        if (mc.field_1724.field_3913.field_3907 < 0.0F) yaw -= 90.0F * forward;
        double cos = Math.cos(Math.toRadians(yaw + 90.0F));
        double sin = Math.sin(Math.toRadians(yaw + 90.0F));
        mc.field_1724.method_18800(cos * speed * forward, mc.field_1724.method_18798().field_1351, sin * speed * forward);
    }

    // ==================== 好友/敌人 ====================
    public static boolean addFriend(String name) {
        if (enemiesSet.remove(name.toLowerCase())) sendMessage("&7Removed enemy &b" + name);
        return friendsSet.add(name.toLowerCase());
    }
    public static boolean removeFriend(String name) { return friendsSet.remove(name.toLowerCase()); }
    public static boolean isFriended(String name) { return friendsSet.contains(name.toLowerCase()); }
    public static boolean addEnemy(String name) {
        if (friendsSet.remove(name.toLowerCase())) sendMessage("&7Removed friend &b" + name);
        return enemiesSet.add(name.toLowerCase());
    }
    public static boolean removeEnemy(String name) { return enemiesSet.remove(name.toLowerCase()); }
    public static boolean isEnemy(String name) { return enemiesSet.contains(name.toLowerCase()); }

    // ==================== 相机工具 ====================
    public static float getCameraYaw() {
        if (mc.field_1724 == null) return 0;
        return mc.field_1724.method_36454();
    }

    public static float getCameraPitch() {
        if (mc.field_1724 == null) return 0;
        return mc.field_1724.method_36455();
    }

    public static class_243 getCameraPos() {
        if (mc.field_1724 == null) return class_243.field_1353;
        return mc.field_1724.method_33571();
    }

    public static class_243 getLookVec() {
        if (mc.field_1724 == null) return class_243.field_1353;
        float yaw = (float) Math.toRadians(mc.field_1724.method_36454());
        float pitch = (float) Math.toRadians(mc.field_1724.method_36455());
        return new class_243(
            -Math.sin(yaw) * Math.cos(pitch),
            -Math.sin(pitch),
            Math.cos(yaw) * Math.cos(pitch)
        );
    }

    // ==================== 距离/射线工具 ====================
    public static double getDistanceToEye(class_1297 entity) {
        if (mc.field_1724 == null || entity == null) return Double.MAX_VALUE;
        return entity.method_33571().method_1022(mc.field_1724.method_33571());
    }

    public static double raycastDistanceSq(class_1297 entity, double maxReach, boolean calcRotation) {
        if (mc.field_1724 == null || entity == null) return Double.MAX_VALUE;
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 entityPos = entity.method_19538().method_1031(0, entity.method_17682() / 2.0, 0);
        return eyePos.method_1025(entityPos);
    }

    // ==================== 视线检查 ====================
    public static boolean canSeeVec(class_243 from, class_243 to) {
        if (mc.field_1687 == null) return false;
        class_3965 result = mc.field_1687.method_17742(new net.minecraft.class_3959(
            from, to,
            net.minecraft.class_3959.class_3960.field_17558,
            net.minecraft.class_3959.class_242.field_1348,
            mc.field_1724
        ));
        return result.method_17783() == class_239.class_240.field_1333;
    }

    public static boolean canPlayerBeSeen(class_1309 player) {
        if (mc.field_1724 == null || player == null) return false;
        return canSeeVec(mc.field_1724.method_33571(), player.method_33571());
    }

    // ==================== FOV检查 ====================
    public static boolean inFov(float fov, class_2338 blockPos) {
        if (mc.field_1724 == null) return false;
        float angle = getAngleToBlock(blockPos);
        return Math.abs(angle) < fov / 2.0f;
    }

    public static boolean inFov(float fov, class_1297 entity) {
        if (mc.field_1724 == null || entity == null) return false;
        float angle = getAngleToEntity(entity);
        return Math.abs(angle) < fov / 2.0f;
    }

    public static boolean inFov(float origin, float fov, float targetYaw) {
        float diff = Math.abs(origin - targetYaw) % 360;
        if (diff > 180) diff = 360 - diff;
        return diff < fov / 2.0f;
    }

    private static float getAngleToBlock(class_2338 pos) {
        if (mc.field_1724 == null) return 180;
        double diffX = pos.method_10263() + 0.5 - mc.field_1724.method_23317();
        double diffZ = pos.method_10260() + 0.5 - mc.field_1724.method_23321();
        float yaw = (float) (Math.toDegrees(Math.atan2(diffZ, diffX)) - 90);
        return wrapAngleTo180(yaw - mc.field_1724.method_36454());
    }

    private static float getAngleToEntity(class_1297 entity) {
        if (mc.field_1724 == null) return 180;
        double diffX = entity.method_23317() - mc.field_1724.method_23317();
        double diffZ = entity.method_23321() - mc.field_1724.method_23321();
        float yaw = (float) (Math.toDegrees(Math.atan2(diffZ, diffX)) - 90);
        return wrapAngleTo180(yaw - mc.field_1724.method_36454());
    }

    public static float wrapAngleTo180(float angle) {
        angle %= 360.0F;
        if (angle >= 180.0F) angle -= 360.0F;
        if (angle < -180.0F) angle += 360.0F;
        return angle;
    }

    // ==================== 虚空检查 ====================
    public static boolean overVoid(double x, double y, double z) {
        if (mc.field_1687 == null) return false;
        if (y > 0) return false;
        for (int i = (int) y; i > -64; i--) {
            if (!mc.field_1687.method_8320(new class_2338((int) x, i, (int) z)).method_26215()) return false;
        }
        return true;
    }

    // ==================== 实体检查 ====================
    public static boolean isConsuming(class_1297 entity) {
        if (entity instanceof class_1657 player) {
            return player.method_6115();
        }
        return false;
    }

    public static boolean holdingFood(class_1309 entity) {
        if (entity instanceof class_1657 player) {
            class_1792 item = player.method_6047().method_7909();
            return item.method_57347().method_57832(class_9334.field_50075);
        }
        return false;
    }

    public static boolean holdingBow() {
        if (mc.field_1724 == null) return false;
        return mc.field_1724.method_6047().method_7909() instanceof class_1753;
    }

    public static boolean holdingFireball() {
        if (mc.field_1724 == null) return false;
        return mc.field_1724.method_6047().method_7909() == class_1802.field_8814;
    }

    public static boolean isInTabList(class_1657 player) {
        if (mc.method_1562() == null) return false;
        return mc.method_1562().method_2871(player.method_5667()) != null;
    }

    public static int getColorFromEntity(class_1297 entity) {
        if (entity instanceof class_1657) {
            return isEnemy(entity.method_5477().getString()) ? 0xFFFF0000 : 0xFF00FF00;
        }
        return 0xFFFFFFFF;
    }

    // ==================== 服务器信息 ====================
    public static String getServerName() {
        if (mc.method_1562() == null) return "Singleplayer";
        String serverAddress = mc.method_1562().method_45734().field_3761;
        return serverAddress != null ? serverAddress : "Unknown";
    }

    public static boolean tabbedIn() {
        return mc.field_1755 == null || mc.field_1755 instanceof class_419;
    }

    // ==================== Tab列表 ====================
    public static List<class_640> getTablist(boolean removeSelf) {
        if (mc.method_1562() == null) return new ArrayList<>();
        return mc.method_1562().method_2880().stream()
            .filter(entry -> !removeSelf || !entry.method_2966().getId().equals(mc.field_1724.method_5667()))
            .collect(Collectors.toList());
    }

    public static List<String> getSidebarLines() {
        List<String> lines = new ArrayList<>();
        return lines;
    }

    // ==================== 工具方法 ====================
    public static double round(double value, int places) {
        return Math.round(value * Math.pow(10, places)) / Math.pow(10, places);
    }

    public static int randomizeInt(int min, int max) {
        return new Random().nextInt(max - min + 1) + min;
    }

    public static double randomizeDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    public static boolean isWholeNumber(double num) {
        return num == Math.floor(num);
    }

    public static String asWholeNum(double input) {
        return String.valueOf((int) input);
    }

    public static int getChroma(long speed, long offset) {
        float hue = (float) ((System.currentTimeMillis() + offset) % speed) / (float) speed;
        return java.awt.Color.HSBtoRGB(hue, 1.0f, 1.0f);
    }

    public static int mergeAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    public static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    public static float getEnum(Object enumObj) {
        return 0;
    }

    public static void log(Object obj) {
        log.info(String.valueOf(obj));
    }

    public static void callScriptFunction(String scriptName, String functionName, Object... args) {}

    public static void attackEntity(Object entity, boolean swing, boolean crits) {}
}
