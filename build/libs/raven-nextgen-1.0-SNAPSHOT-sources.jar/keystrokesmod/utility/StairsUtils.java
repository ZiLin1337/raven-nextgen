package keystrokesmod.utility;

import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2510;
import net.minecraft.class_2680;

public class StairsUtils {
    
    public static boolean isStairs(class_2248 block) {
        return block instanceof class_2510;
    }
    
    public static boolean isStairs(class_2680 state) {
        return state.method_26204() instanceof class_2510;
    }
    
    public static class_2350 getStairsFacing(class_2680 state) {
        if (state.method_26204() instanceof class_2510) {
            return state.method_11654(class_2510.field_11571);
        }
        return class_2350.field_11043;
    }
    
    public static boolean isTopHalf(class_2680 state) {
        if (state.method_26204() instanceof class_2510) {
            return state.method_11654(class_2510.field_11572) == net.minecraft.class_2760.field_12619;
        }
        return false;
    }
    
    public static boolean isUpsideDown(class_2680 state) {
        return isTopHalf(state);
    }
}
