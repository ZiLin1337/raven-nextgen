package keystrokesmod.utility;

import net.minecraft.class_1657;
import net.minecraft.class_1799;

public final class BlockAnimationUtils {
    private BlockAnimationUtils() {
    }

    public static void beginRender(class_1657 player) {
    }

    public static void endRender(class_1657 player) {
    }

    public static boolean shouldForceBlockAnimation(class_1657 player, class_1799 stack) {
        return false;
    }
}
