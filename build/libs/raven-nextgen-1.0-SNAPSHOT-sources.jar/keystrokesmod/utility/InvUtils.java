package keystrokesmod.utility;

import java.util.function.Predicate;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2680;

public class InvUtils implements IMinecraftInstance {
    public static int previousSlot = -1;
    public static int[] invSlots;
    
    public static final int HOTBAR_START = 0;
    public static final int HOTBAR_END = 8;
    public static final int OFFHAND = 40;
    
    public static boolean testInMainHand(Predicate<class_1799> predicate) {
        return predicate.test(mc.field_1724.method_6047());
    }
    
    public static boolean testInMainHand(class_1792... items) {
        return testInMainHand(itemStack -> {
            for (var item : items) if (itemStack.method_31574(item)) return true;
            return false;
        });
    }
    
    public static boolean testInOffHand(Predicate<class_1799> predicate) {
        return predicate.test(mc.field_1724.method_6079());
    }
    
    public static boolean testInOffHand(class_1792... items) {
        return testInOffHand(itemStack -> {
            for (var item : items) if (itemStack.method_31574(item)) return true;
            return false;
        });
    }
    
    public static boolean testInHands(Predicate<class_1799> predicate) {
        return testInMainHand(predicate) || testInOffHand(predicate);
    }
    
    public static boolean testInHands(class_1792... items) {
        return testInMainHand(items) || testInOffHand(items);
    }
    
    public static boolean testInHotbar(Predicate<class_1799> predicate) {
        if (testInHands(predicate)) return true;
        for (int i = HOTBAR_START; i <= HOTBAR_END; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (predicate.test(stack)) return true;
        }
        return false;
    }
    
    public static boolean testInHotbar(class_1792... items) {
        return testInHotbar(itemStack -> {
            for (class_1792 item : items) if (itemStack.method_31574(item)) return true;
            return false;
        });
    }
    
    public static FindItemResult findEmpty() {
        return find(class_1799::method_7960);
    }
    
    public static FindItemResult findInHotbar(class_1792... items) {
        return findInHotbar(itemStack -> {
            for (class_1792 item : items) {
                if (itemStack.method_7909() == item) return true;
            }
            return false;
        });
    }
    
    public static FindItemResult findInHotbar(Predicate<class_1799> isGood) {
        if (testInOffHand(isGood)) {
            return new FindItemResult(OFFHAND, mc.field_1724.method_6079().method_7947(), mc.field_1724.method_6079().method_7914());
        }
        if (testInMainHand(isGood)) {
            return new FindItemResult(mc.field_1724.method_31548().field_7545, mc.field_1724.method_6047().method_7947(), mc.field_1724.method_6047().method_7914());
        }
        return find(isGood, 0, 8);
    }
    
    public static FindItemResult find(class_1792... items) {
        return find(itemStack -> {
            for (class_1792 item : items) {
                if (itemStack.method_7909() == item) return true;
            }
            return false;
        });
    }
    
    public static FindItemResult find(Predicate<class_1799> isGood) {
        if (mc.field_1724 == null) return new FindItemResult(0, 0, 0);
        return find(isGood, 0, mc.field_1724.method_31548().method_5439());
    }
    
    public static FindItemResult find(Predicate<class_1799> isGood, int start, int end) {
        if (mc.field_1724 == null) return new FindItemResult(0, 0, 0);
        int slot = -1, count = 0, maxCount = 0;
        for (int i = start; i <= end; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (isGood.test(stack)) {
                if (slot == -1) slot = i;
                count += stack.method_7947();
                maxCount += stack.method_7914();
            }
        }
        return new FindItemResult(slot, count, maxCount);
    }
    
    public static FindItemResult findFastestTool(class_2680 state, Boolean inv) {
        float bestScore = 1;
        int slot = -1;
        for (int i = 0; i < (inv ? mc.field_1724.method_31548().method_5439() : 9); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7951(state)) continue;
            float score = stack.method_7924(state);
            if (score > bestScore) {
                bestScore = score;
                slot = i;
            }
        }
        return new FindItemResult(slot, 1, 1);
    }
    
    public static boolean swap(int slot, boolean swapBack) {
        if (slot == OFFHAND) return true;
        if (slot < 0 || slot > 8) return false;
        if (swapBack && previousSlot == -1) previousSlot = mc.field_1724.method_31548().field_7545;
        else if (!swapBack) previousSlot = -1;
        mc.field_1724.method_31548().field_7545 = slot;
        // syncSelectedSlot removed
        return true;
    }
    
    public static boolean swapBack() {
        if (previousSlot == -1) return false;
        boolean return_ = swap(previousSlot, false);
        previousSlot = -1;
        return return_;
    }
    
    public static boolean invSwap(int slot) {
        if (slot >= 0) {
            int containerSlot = slot;
            if (slot < 9) containerSlot += 36;
            else if (slot == 40) containerSlot = 45;
            class_1703 handler = mc.field_1724.field_7512;
            int selectedSlot = mc.field_1724.method_31548().field_7545;
            mc.field_1761.method_2906(handler.field_7763, containerSlot, selectedSlot, class_1713.field_7791, mc.field_1724);
            invSlots = new int[]{containerSlot, selectedSlot};
            return true;
        }
        return false;
    }
    
    public static void invSwapBack() {
        if (invSlots == null || invSlots.length < 2) return;
        class_1703 handler = mc.field_1724.field_7512;
        mc.field_1761.method_2906(handler.field_7763, invSlots[0], invSlots[1], class_1713.field_7791, mc.field_1724);
    }
    
    public static class FindItemResult {
        private final int slot;
        private final int count;
        private final int maxCount;
        
        public FindItemResult(int slot, int count, int maxCount) {
            this.slot = slot;
            this.count = count;
            this.maxCount = maxCount;
        }
        
        public int getSlot() {
            return slot;
        }
        
        public int getCount() {
            return count;
        }
        
        public int getMaxCount() {
            return maxCount;
        }
        
        public boolean isPresent() {
            return slot != -1;
        }
    }
}
