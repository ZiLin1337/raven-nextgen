package keystrokesmod.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_2757;

public class ServerUtils implements IMinecraftInstance {
    private static int grimTransactionCount = 0;
    public static final Map<String, AtomicInteger> playerHealths = new HashMap<>();
    private static float lastHealth = 20f;
    private static int lastFood = 20;
    private static float lastSaturation = 5f;
    
    public static void onScoreboardScore(class_2757 packet) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        String objectiveName = packet.comp_2123();
        String playerName = packet.comp_2122();
        int score = packet.comp_2124();
        if (!playerName.equals(mc.field_1724.method_5477().getString())) {
            if ("belowHealth".equals(objectiveName) || "health".equals(objectiveName)) {
                if (!playerHealths.containsKey(playerName)) {
                    playerHealths.put(playerName, new AtomicInteger());
                }
                playerHealths.get(playerName).set(score);
            }
        }
    }
    
    public static void onHealthUpdate(float health, int food, float saturation) {
        lastHealth = health;
        lastFood = food;
        lastSaturation = saturation;
    }
    
    public static float getPlayerHealth(String playerName) {
        AtomicInteger health = playerHealths.get(playerName);
        return health != null ? health.get() : -1;
    }
    
    public static void setPlayerHealth(String playerName, float health) {
        if (!playerHealths.containsKey(playerName)) {
            playerHealths.put(playerName, new AtomicInteger());
        }
        playerHealths.get(playerName).set((int) health);
    }
    
    public static Map<String, AtomicInteger> getAllPlayerHealths() {
        return playerHealths;
    }
    
    public static float getLastHealth() {
        return lastHealth;
    }
    
    public static int getLastFood() {
        return lastFood;
    }
    
    public static float getLastSaturation() {
        return lastSaturation;
    }
    
    public static void updatePlayerHealths() {
        if (mc.field_1687 == null) return;
        for (var player : mc.field_1687.method_18456()) {
            if (player != mc.field_1724 && playerHealths.containsKey(player.method_5477().getString())) {
                int health = playerHealths.get(player.method_5477().getString()).get();
                player.method_6033(Math.max(1, health));
            }
        }
    }
    
    public static void clearHealthData() {
        playerHealths.clear();
        grimTransactionCount = 0;
    }
    
    public static void incrementGrimTransaction() {
        grimTransactionCount++;
    }
    
    public static int getGrimTransactionCount() {
        return grimTransactionCount;
    }
    
    public static void resetGrimTransaction() {
        grimTransactionCount = 0;
    }
}
