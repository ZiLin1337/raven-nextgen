package keystrokesmod.utility;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3532;

public class RotationUtils implements IMinecraftInstance {
    public static float[] getRotations(class_1297 entity) {
        return new float[]{0, 0};
    }

    public static float[] getRotations(class_2338 pos) {
        return new float[]{0, 0};
    }

    public static float[] getRotationsTo(double x, double y, double z) {
        return new float[]{0, 0};
    }

    public static float wrapAngleTo180(float angle) {
        return class_3532.method_15393(angle);
    }
}