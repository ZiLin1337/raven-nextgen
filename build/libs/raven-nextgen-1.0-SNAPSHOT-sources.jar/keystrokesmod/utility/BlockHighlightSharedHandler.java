package keystrokesmod.utility;

import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.utility.Utils;
import net.minecraft.class_310;
import keystrokesmod.event.TickEvent;
import keystrokesmod.event.EntityJoinWorldEvent;
public final class BlockHighlightSharedHandler {

    private static final class_310 mc = class_310.method_1551();

    
    public void onReceivePacket(ReceivePacketEvent e) {
    }

    
    public void onClientTick(TickEvent.ClientTickEvent e) {
    }

    
    public void onEntityJoinWorld(EntityJoinWorldEvent e) {
    }
}
