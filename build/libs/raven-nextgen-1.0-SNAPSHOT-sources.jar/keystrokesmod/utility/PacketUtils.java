package keystrokesmod.utility;

import net.minecraft.class_2596;

public class PacketUtils {
    public static void sendPacketNoEvent(class_2596<?> packet) {
    }

    public static void receivePacketNoEvent(class_2596<?> packet) {
    }
}