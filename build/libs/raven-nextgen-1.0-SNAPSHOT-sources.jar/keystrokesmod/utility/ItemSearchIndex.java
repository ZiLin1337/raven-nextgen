package keystrokesmod.utility;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class ItemSearchIndex {
    private static final Map<String, class_1792> itemMap = new HashMap<>();
    
    static {
        itemMap.put("sword", class_1802.field_8802);
        itemMap.put("diamond_sword", class_1802.field_8802);
        itemMap.put("iron_sword", class_1802.field_8371);
        itemMap.put("stone_sword", class_1802.field_8528);
        itemMap.put("wooden_sword", class_1802.field_8091);
        itemMap.put("golden_sword", class_1802.field_8845);
        itemMap.put("netherite_sword", class_1802.field_22022);
        
        itemMap.put("pickaxe", class_1802.field_8377);
        itemMap.put("diamond_pickaxe", class_1802.field_8377);
        itemMap.put("iron_pickaxe", class_1802.field_8403);
        itemMap.put("stone_pickaxe", class_1802.field_8387);
        itemMap.put("wooden_pickaxe", class_1802.field_8647);
        
        itemMap.put("axe", class_1802.field_8556);
        itemMap.put("diamond_axe", class_1802.field_8556);
        itemMap.put("iron_axe", class_1802.field_8475);
        
        itemMap.put("shovel", class_1802.field_8250);
        itemMap.put("bow", class_1802.field_8102);
        itemMap.put("crossbow", class_1802.field_8399);
        itemMap.put("trident", class_1802.field_8547);
        itemMap.put("shield", class_1802.field_8255);
        itemMap.put("ender_pearl", class_1802.field_8634);
        itemMap.put("ender_pearls", class_1802.field_8634);
        itemMap.put("apple", class_1802.field_8463);
        itemMap.put("gap", class_1802.field_8463);
        itemMap.put("gapple", class_1802.field_8463);
        itemMap.put("enchant_golden_apple", class_1802.field_8367);
        itemMap.put("totem", class_1802.field_8288);
        itemMap.put("crystal", class_1802.field_8301);
    }
    
    public static class_1792 getItem(String name) {
        return itemMap.get(name.toLowerCase());
    }
}
