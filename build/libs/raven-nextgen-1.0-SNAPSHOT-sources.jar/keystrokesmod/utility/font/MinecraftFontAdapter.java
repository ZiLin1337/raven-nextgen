package keystrokesmod.utility.font;

import net.minecraft.class_327;

public class MinecraftFontAdapter {
    public static void drawString(class_327 fontRenderer, String text, float x, float y, int color, boolean shadow) {
        // TextRenderer methods changed in 1.21.4
    }

    public static float getStringWidth(class_327 fontRenderer, String text) {
        return fontRenderer != null ? fontRenderer.method_1727(text) : 0;
    }
}