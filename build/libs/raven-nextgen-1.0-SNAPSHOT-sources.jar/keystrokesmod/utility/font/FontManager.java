package keystrokesmod.utility.font;

import net.minecraft.class_310;
import net.minecraft.class_327;

public class FontManager implements keystrokesmod.utility.IMinecraftInstance {
    private static boolean initialized = false;
    
    public static void init() {
        if (initialized) return;
        initialized = true;
    }
    
    public static class_327 getDefaultFont() {
        return class_310.method_1551().field_1772;
    }
    
    public static void drawString(String text, float x, float y, int color, boolean shadow) {
        // Stub - needs DrawContext to work properly
    }
    
    public static float getStringWidth(String text) {
        class_327 font = getDefaultFont();
        return font != null ? font.method_1727(text) : 0;
    }
    
    public static int getFontHeight() {
        return 9;
    }
}
