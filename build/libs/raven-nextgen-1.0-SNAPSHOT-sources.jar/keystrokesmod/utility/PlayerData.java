package keystrokesmod.utility;

import net.minecraft.class_1657;

public class PlayerData {
    public double speed;
    public int aboveVoidTicks;
    public int fastTick;
    public int autoBlockTicks;
    public int ticksExisted;
    public int lastSneakTick;
    public double posZ;
    public int sneakTicks;
    public int noSlowTicks;
    public double posY;
    public boolean sneaking;
    public double posX;
    public double serverPosX;
    public double serverPosY;
    public double serverPosZ;

    public void update(class_1657 entityPlayer) {
    }

    public void updateSneak(final class_1657 entityPlayer) {
    }

    public void updateServerPos(class_1657 entityPlayer) {
    }
}
