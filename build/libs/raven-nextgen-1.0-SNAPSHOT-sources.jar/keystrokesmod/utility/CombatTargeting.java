package keystrokesmod.utility;

import net.minecraft.class_1297;

public class CombatTargeting {
    public static boolean isBot(class_1297 entity) {
        return false;
    }

    public static boolean isFriend(class_1297 entity) {
        return false;
    }

    public static boolean isEnemy(class_1297 entity) {
        return false;
    }

    public static boolean isValidTarget(class_1297 entity) {
        return false;
    }
}