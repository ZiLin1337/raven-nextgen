package keystrokesmod.utility.particle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_243;

public class ParticleRenderer {
    private static final List<ParticleData> particles = new ArrayList<>();
    
    public static void addParticle(class_243 pos, class_243 velocity, int color, int lifetime) {
        particles.add(new ParticleData(pos, velocity, color, lifetime, 0));
    }
    
    public static void update() {
        Iterator<ParticleData> it = particles.iterator();
        while (it.hasNext()) {
            ParticleData p = it.next();
            p.age++;
            if (p.age >= p.lifetime) {
                it.remove();
            } else {
                p.pos = p.pos.method_1019(p.velocity);
                p.velocity = p.velocity.method_1021(0.98);
            }
        }
    }
    
    public static List<ParticleData> getParticles() {
        return particles;
    }
    
    public static void clear() {
        particles.clear();
    }
    
    public static void render(Object engine) {
        // Render particles using OpenGL
    }
    
    public static class ParticleData {
        public class_243 pos;
        public class_243 velocity;
        public int color;
        public int lifetime;
        public int age;
        
        public ParticleData(class_243 pos, class_243 velocity, int color, int lifetime, int age) {
            this.pos = pos;
            this.velocity = velocity;
            this.color = color;
            this.lifetime = lifetime;
            this.age = age;
        }
    }
}
