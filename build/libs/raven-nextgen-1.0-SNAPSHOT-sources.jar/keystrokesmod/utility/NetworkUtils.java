package keystrokesmod.utility;

import keystrokesmod.Raven;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;

public class NetworkUtils implements IMinecraftInstance {
    
    public static void sendPacket(class_2596<?> packet) {
        if (mc.field_1724 != null && mc.method_1562() != null) {
            mc.method_1562().method_52787(packet);
        }
    }
    
    public static void sendPosition(double x, double y, double z, boolean onGround) {
        sendPacket(new class_2828.class_2829(x, y, z, onGround, false));
    }
    
    public static void sendRotation(float yaw, float pitch, boolean onGround) {
        sendPacket(new class_2828.class_2831(yaw, pitch, onGround, false));
    }
    
    public static void sendFull(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        sendPacket(new class_2828.class_2830(x, y, z, yaw, pitch, onGround, false));
    }
    
    public static class_243 getPacketPos() {
        return mc.field_1724 != null ? mc.field_1724.method_19538() : class_243.field_1353;
    }
    
    public static void sendPositionAndRotation(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        sendPacket(new class_2828.class_2831(yaw, pitch, onGround, false));
    }
}
