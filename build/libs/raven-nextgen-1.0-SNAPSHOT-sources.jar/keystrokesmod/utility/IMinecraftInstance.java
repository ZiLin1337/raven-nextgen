package keystrokesmod.utility;

import net.minecraft.class_310;

public interface IMinecraftInstance {

    class_310 mc = class_310.method_1551();

}