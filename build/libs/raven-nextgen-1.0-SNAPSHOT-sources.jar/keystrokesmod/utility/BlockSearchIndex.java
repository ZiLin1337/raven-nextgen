package keystrokesmod.utility;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class BlockSearchIndex {
    private static final Map<String, class_2248> blockMap = new HashMap<>();
    
    static {
        blockMap.put("chest", class_2246.field_10034);
        blockMap.put("ender_chest", class_2246.field_10443);
        blockMap.put("trapped_chest", class_2246.field_10380);
        blockMap.put("shulker_box", class_2246.field_10603);
        blockMap.put("barrel", class_2246.field_16328);
        
        blockMap.put("cobweb", class_2246.field_10343);
        blockMap.put("web", class_2246.field_10343);
        blockMap.put("slime", class_2246.field_10030);
        blockMap.put("slime_block", class_2246.field_10030);
        blockMap.put("honey", class_2246.field_21211);
        blockMap.put("honey_block", class_2246.field_21211);
        
        blockMap.put("water", class_2246.field_10382);
        blockMap.put("lava", class_2246.field_10164);
        blockMap.put("flowing_water", class_2246.field_10382);
        blockMap.put("flowing_lava", class_2246.field_10164);
        
        blockMap.put("obsidian", class_2246.field_10540);
        blockMap.put("bedrock", class_2246.field_9987);
        blockMap.put("end_portal", class_2246.field_10027);
        blockMap.put("barrier", class_2246.field_10499);
        blockMap.put("air", class_2246.field_10124);
    }
    
    public static class_2248 getBlock(String name) {
        return blockMap.get(name.toLowerCase());
    }
}
