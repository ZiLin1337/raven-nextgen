package keystrokesmod.utility;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BlockUtils implements IMinecraftInstance {
    public static boolean isSamePos(class_2338 pos1, class_2338 pos2) {
        return pos1.equals(pos2);
    }

    public static class_2338 pos(double x, double y, double z) {
        return class_2338.method_49637(x, y, z);
    }

    public static class_2680 getBlockState(class_2338 pos) {
        if (mc.field_1687 == null) return null;
        return mc.field_1687.method_8320(pos);
    }

    public static float getBlockHardness(class_2680 state) {
        return state.method_26214(mc.field_1687, pos(0, 0, 0));
    }
}
