package keystrokesmod.utility;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BedFootHighlightMatcher {
    public static boolean matches(class_2680 state, class_2338 pos) {
        return false;
    }
}