package keystrokesmod.utility;

public class FireballSimulator {
}