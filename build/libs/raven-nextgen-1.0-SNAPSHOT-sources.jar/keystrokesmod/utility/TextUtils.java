package keystrokesmod.utility;

import net.minecraft.class_2561;

public class TextUtils {
    public static String stripFormatting(class_2561 text) {
        return text != null ? text.getString() : "";
    }

    public static String getFormattedText(class_2561 text) {
        return text != null ? text.getString() : "";
    }

    public static String getUnformattedText(class_2561 text) {
        return text != null ? text.getString() : "";
    }

    public static boolean isEmpty(class_2561 text) {
        return text == null || text.getString().isEmpty();
    }
}