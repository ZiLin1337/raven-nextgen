package keystrokesmod.utility;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_640;

public class PlayerSearchIndex implements IMinecraftInstance {
    
    public static class_1657 getClosestPlayer(double range) {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        class_1657 closest = null;
        double closestDist = range;
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724) continue;
            double dist = player.method_5858(mc.field_1724);
            if (dist < closestDist) {
                closestDist = dist;
                closest = player;
            }
        }
        return closest;
    }
    
    public static class_1657 getClosestEnemy(double range) {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        class_1657 closest = null;
        double closestDist = range;
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724) continue;
            if (Utils.enemies.contains(player.method_5477().getString().toLowerCase())) {
                double dist = player.method_5858(mc.field_1724);
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = player;
                }
            }
        }
        return closest;
    }
    
    public static List<class_1657> getPlayersInRange(double range) {
        List<class_1657> players = new ArrayList<>();
        if (mc.field_1687 == null || mc.field_1724 == null) return players;
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724) continue;
            if (player.method_5858(mc.field_1724) <= range * range) {
                players.add(player);
            }
        }
        return players;
    }
    
    public static boolean isBot(class_1657 player) {
        class_640 entry = mc.method_1562().method_2871(player.method_5667());
        if (entry == null) return true;
        return entry.method_2966().getName() == null;
    }
}
