package keystrokesmod.utility;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_6880;

public class PotionSearchIndex {
    private static final Map<String, class_6880<class_1291>> potionMap = new HashMap<>();
    
    static {
        potionMap.put("speed", class_1294.field_5904);
        potionMap.put("slowness", class_1294.field_5909);
        potionMap.put("haste", class_1294.field_5917);
        potionMap.put("mining_fatigue", class_1294.field_5901);
        potionMap.put("strength", class_1294.field_5910);
        potionMap.put("weakness", class_1294.field_5911);
        potionMap.put("regeneration", class_1294.field_5924);
        potionMap.put("health_boost", class_1294.field_5914);
        potionMap.put("absorption", class_1294.field_5898);
        potionMap.put("resistance", class_1294.field_5907);
        potionMap.put("fire_resistance", class_1294.field_5918);
        potionMap.put("invisibility", class_1294.field_5905);
        potionMap.put("night_vision", class_1294.field_5925);
        potionMap.put("jump_boost", class_1294.field_5913);
        potionMap.put("nausea", class_1294.field_5916);
        potionMap.put("regeneration", class_1294.field_5924);
        potionMap.put("poison", class_1294.field_5899);
        potionMap.put("wither", class_1294.field_5920);
        potionMap.put("water_breathing", class_1294.field_5923);
        potionMap.put("glowing", class_1294.field_5912);
        potionMap.put("levitation", class_1294.field_5902);
        potionMap.put("luck", class_1294.field_5926);
        potionMap.put("unluck", class_1294.field_5908);
    }
    
    public static class_6880<class_1291> getPotion(String name) {
        return potionMap.get(name.toLowerCase());
    }
    
    public static boolean hasPotion(Iterable<class_1293> effects, String name) {
        class_6880<class_1291> effect = getPotion(name);
        if (effect == null) return false;
        for (class_1293 instance : effects) {
            if (instance.method_5579() == effect) return true;
        }
        return false;
    }
}
