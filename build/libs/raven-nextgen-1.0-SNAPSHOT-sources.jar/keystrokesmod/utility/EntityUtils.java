package keystrokesmod.utility;

import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_746;

public class EntityUtils implements IMinecraftInstance {
    
    public static class_1657 getClosestPlayer(double range) {
        if (mc.field_1687 == null) return null;
        return mc.field_1687.method_18456().stream()
            .filter(e -> !(e instanceof class_746) && !e.method_7325())
            .filter(e -> mc.field_1724.method_5858(e) <= range * range)
            .min(Comparator.comparingDouble(e -> mc.field_1724.method_5858(e)))
            .orElse(null);
    }
    
    public static boolean isInsideBlock() {
        if (mc.field_1687 == null || mc.field_1724 == null) return false;
        class_2338 pos = mc.field_1724.method_24515();
        if (mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10443) {
            return true;
        }
        return mc.field_1687.method_39454(mc.field_1724, mc.field_1724.method_5829());
    }
    
    public static boolean isInWeb(class_1657 player) {
        if (mc.field_1687 == null || player == null) return false;
        class_2338 pos = player.method_24515();
        return mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10343 ||
               mc.field_1687.method_8320(pos.method_10084()).method_26204() == class_2246.field_10343;
    }
    
    public static boolean isEntityLiving(class_1297 entity) {
        return entity instanceof net.minecraft.class_1309;
    }
    
    public static boolean isPlayer(class_1297 entity) {
        return entity instanceof class_1657;
    }
    
    public static boolean isSelf(class_1297 entity) {
        return entity == mc.field_1724;
    }
    
    public static List<class_1657> getPlayersInRange(double range) {
        if (mc.field_1687 == null || mc.field_1724 == null) return List.of();
        return mc.field_1687.method_18456().stream()
            .filter(e -> !(e instanceof class_746))
            .filter(e -> mc.field_1724.method_5858(e) <= range * range)
            .collect(java.util.stream.Collectors.toList());
    }
    
    public static boolean canBeSeen(class_1297 target, class_1297 from, double range) {
        if (mc.field_1687 == null) return false;
        return mc.field_1687.method_17742(new net.minecraft.class_3959(from.method_33571(), target.method_19538(), net.minecraft.class_3959.class_3960.field_17558, net.minecraft.class_3959.class_242.field_1348, mc.field_1724)).method_17783() == net.minecraft.class_239.class_240.field_1333;
    }
}
