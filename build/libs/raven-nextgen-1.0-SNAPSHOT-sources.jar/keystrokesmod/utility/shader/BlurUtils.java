package keystrokesmod.utility.shader;

import net.minecraft.class_279;
import net.minecraft.class_310;

public class BlurUtils {
    private static class_310 mc = class_310.method_1551();
    private static class_279 blurProcessor;

    public static void load() {
    }

    public static void blur(float strength) {
    }
}
