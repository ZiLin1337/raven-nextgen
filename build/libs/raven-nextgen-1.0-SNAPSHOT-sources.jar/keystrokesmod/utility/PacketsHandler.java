package keystrokesmod.utility;

import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.event.SendPacketEvent;
import java.util.concurrent.atomic.AtomicInteger;

public class PacketsHandler implements IMinecraftInstance {
    public AtomicInteger playerSlot = new AtomicInteger(-1);
    public AtomicInteger serverSlot = new AtomicInteger(-1);
    private final boolean handleSlots = true;

    
    public void onSendPacket(SendPacketEvent e) {
    }

    
    public void onReceivePacket(ReceivePacketEvent e) {
    }
}