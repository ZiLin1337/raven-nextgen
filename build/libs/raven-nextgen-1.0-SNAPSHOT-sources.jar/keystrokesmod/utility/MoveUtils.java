package keystrokesmod.utility;

import net.minecraft.class_1294;

public class MoveUtils implements IMinecraftInstance {
    
    public static boolean isMoving() {
        return mc.field_1724.field_3913.field_3905 != 0 || mc.field_1724.field_3913.field_3907 != 0;
    }
    
    public static double getSpeed() {
        return Math.sqrt(mc.field_1724.method_18798().field_1352 * mc.field_1724.method_18798().field_1352 + mc.field_1724.method_18798().field_1350 * mc.field_1724.method_18798().field_1350);
    }
    
    public static double getBaseSpeed(boolean slow, double customSpeed) {
        double baseSpeed = customSpeed;
        if (mc.field_1724.method_6059(class_1294.field_5904)) {
            int amplifier = mc.field_1724.method_6112(class_1294.field_5904).method_5578();
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        if (slow && mc.field_1724.method_6059(class_1294.field_5909)) {
            int amplifier = mc.field_1724.method_6112(class_1294.field_5909).method_5578();
            baseSpeed /= 1.0 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }
    
    public static double getBaseSpeed(boolean slow) {
        return getBaseSpeed(slow, 0.2873);
    }
    
    public static double getDistance2D() {
        if (mc.field_1724 == null) return 0;
        double dx = mc.field_1724.method_23317() - mc.field_1724.field_6014;
        double dz = mc.field_1724.method_23321() - mc.field_1724.field_5969;
        return Math.sqrt(dx * dx + dz * dz);
    }
    
    public static double getJumpBoost() {
        if (mc.field_1724 == null) return 0;
        if (mc.field_1724.method_6059(class_1294.field_5913)) {
            return (mc.field_1724.method_6112(class_1294.field_5913).method_5578() + 1) * 0.1;
        }
        return 0;
    }
    
    public static double getMotionY() {
        if (mc.field_1724 == null) return 0;
        return mc.field_1724.method_18798().field_1351;
    }
    
    public static void setMotionY(double y) {
        if (mc.field_1724 == null) return;
        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, y, mc.field_1724.method_18798().field_1350);
    }
    
    public static void setMotionX(double x) {
        mc.field_1724.method_18800(x, mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350);
    }
    
    public static void setMotionZ(double z) {
        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1351, z);
    }
    
    public static void strafe(double speed) {
        if (!isMoving()) return;
        double yaw = getDirection();
        mc.field_1724.method_18800(-Math.sin(yaw) * speed, mc.field_1724.method_18798().field_1351, Math.cos(yaw) * speed);
    }
    
    public static double getDirection() {
        float yaw = mc.field_1724.method_36454();
        float forward = mc.field_1724.field_3913.field_3905;
        float strafe = mc.field_1724.field_3913.field_3907;
        if (forward < 0) {
            yaw += 180;
        }
        float modifier = 1;
        if (forward != 0) {
            modifier = forward < 0 ? -0.5f : 0.5f;
        }
        if (strafe > 0) {
            yaw -= 90 * modifier;
        }
        if (strafe < 0) {
            yaw += 90 * modifier;
        }
        return Math.toRadians(yaw);
    }
    
    public static double getDirection(float rotationYaw, final double moveForward, final double moveStrafing) {
        if (moveForward < 0F) rotationYaw += 180F;
        float forward = 1F;
        if (moveForward < 0F) forward = -0.5F;
        else if (moveForward > 0F) forward = 0.5F;
        if (moveStrafing > 0F) rotationYaw -= 90F * forward;
        if (moveStrafing < 0F) rotationYaw += 90F * forward;
        return Math.toRadians(rotationYaw);
    }
    
    public static float getMoveForward() {
        if (mc.field_1724 == null) return 0;
        return mc.field_1724.field_3913.field_3905;
    }
    
    public static float getMoveStrafe() {
        if (mc.field_1724 == null) return 0;
        return mc.field_1724.field_3913.field_3907;
    }
    
    public static double[] getMotion(double speed) {
        if (mc.field_1724 == null) return new double[]{0, 0};
        float forward = mc.field_1724.field_3913.field_3905;
        float strafe = mc.field_1724.field_3913.field_3907;
        float yaw = mc.field_1724.method_36454();
        if (forward == 0 && strafe == 0) {
            return new double[]{0, 0};
        }
        if (forward != 0) {
            if (strafe > 0) {
                yaw -= (forward > 0 ? 45 : -45);
            } else if (strafe < 0) {
                yaw += (forward > 0 ? 45 : -45);
            }
            strafe = 0;
            forward = forward > 0 ? 1 : -1;
        }
        double sin = Math.sin(Math.toRadians(yaw));
        double cos = Math.cos(Math.toRadians(yaw));
        double x = forward * speed * -sin + strafe * speed * cos;
        double z = forward * speed * cos + strafe * speed * sin;
        return new double[]{x, z};
    }
    
    public static float getTickDelta() {
        return mc.method_61966().method_60637(true);
    }
    
    public static double[] directionSpeedKey(double speed) {
        if (mc.field_1724 == null) return new double[]{0, 0};
        float forward = (mc.field_1690.field_1894.method_1434() ? 1 : 0) + (mc.field_1690.field_1881.method_1434() ? -1 : 0);
        float side = (mc.field_1690.field_1913.method_1434() ? 1 : 0) + (mc.field_1690.field_1849.method_1434() ? -1 : 0);
        float yaw = mc.field_1724.field_5982 + (mc.field_1724.method_36454() - mc.field_1724.field_5982) * getTickDelta();
        if (forward != 0.0f) {
            if (side > 0.0f) {
                yaw += ((forward > 0.0f) ? -45 : 45);
            } else if (side < 0.0f) {
                yaw += ((forward > 0.0f) ? 45 : -45);
            }
            side = 0.0f;
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        final double sin = Math.sin(Math.toRadians(yaw + 90.0f));
        final double cos = Math.cos(Math.toRadians(yaw + 90.0f));
        final double posX = forward * speed * cos + side * speed * sin;
        final double posZ = forward * speed * sin - side * speed * cos;
        return new double[]{posX, posZ};
    }
    
    public static double[] directionSpeed(double speed) {
        if (mc.field_1724 == null) return new double[]{0, 0};
        float forward = mc.field_1724.field_3913.field_3905;
        float side = mc.field_1724.field_3913.field_3907;
        float yaw = mc.field_1724.field_5982 + (mc.field_1724.method_36454() - mc.field_1724.field_5982) * getTickDelta();
        if (forward != 0.0f) {
            if (side > 0.0f) {
                yaw += ((forward > 0.0f) ? -45 : 45);
            } else if (side < 0.0f) {
                yaw += ((forward > 0.0f) ? 45 : -45);
            }
            side = 0.0f;
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        final double sin = Math.sin(Math.toRadians(yaw + 90.0f));
        final double cos = Math.cos(Math.toRadians(yaw + 90.0f));
        final double posX = forward * speed * cos + side * speed * sin;
        final double posZ = forward * speed * sin - side * speed * cos;
        return new double[]{posX, posZ};
    }
}
