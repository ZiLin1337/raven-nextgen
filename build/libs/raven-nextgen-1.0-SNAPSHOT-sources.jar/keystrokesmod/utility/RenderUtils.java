package keystrokesmod.utility;

import org.lwjgl.BufferUtils;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_276;
import net.minecraft.class_327;

public class RenderUtils implements IMinecraftInstance {
    private static final FloatBuffer MODELVIEW = BufferUtils.createFloatBuffer(16);
    private static final FloatBuffer PROJECTION = BufferUtils.createFloatBuffer(16);
    private static final IntBuffer VIEWPORT = BufferUtils.createIntBuffer(16);
    private static final FloatBuffer SCREEN_COORDS = BufferUtils.createFloatBuffer(3);

    public static final class ProjectionContext {
        private int scaleFactor;
        private final FloatBuffer modelView = BufferUtils.createFloatBuffer(16);
        private final FloatBuffer projection = BufferUtils.createFloatBuffer(16);
        private final IntBuffer viewport = BufferUtils.createIntBuffer(16);
        private final FloatBuffer screenCoords = BufferUtils.createFloatBuffer(3);
    }

    public static void renderBlock(class_2338 pos, int color, boolean outline, boolean shade) {}
    public static void renderChest(class_2338 pos, int color, boolean outline, boolean shade) {}
    public static void renderBlock(class_2338 pos, int color, double y2, boolean outline, boolean shade) {}
    public static void scissor(double x, double y, double width, double height) {}
    public static void scissorPushGui(double x, double y, double width, double height) {}
    public static void scissorPop() {}
    public static boolean isInViewFrustum(class_1297 entity) { return false; }
    public static boolean isInViewFrustum(class_238 bb) { return false; }
    public static void drawRect(double left, double top, double right, double bottom, int color) {}
    public static void drawOutline(float x, float y, float x2, float y2, float lineWidth, int color) {}
    public static void renderBox(double x, double y, double z, double x2, double y2, double z2, int color, boolean outline, boolean shade) {}
    public static void renderEntity(class_1297 e, int type, double expand, double shift, int color, boolean damage) {}
    public static void drawRoundedRectangle(float x, float y, float x2, float y2, float radius, int color) {}
    public static void drawRectangleGL(float x, float y, float x2, float y2, int color) {}
    public static int setAlpha(int rgb, double alpha) { return rgb; }
    public static void drawGradientRect(int left, int top, int right, int bottom, int startColor, int endColor) {}
    public static void drawColoredString(String text, char lineSplit, int x, int y, long s, long shift, boolean rect, class_327 fontRenderer) {}
    public static void drawCircle(double x, double y, double z, double radius, int sides, float lineWidth, int color, boolean chroma) {}
    public static void drawTracerLine(class_1297 e, int color, float lineWidth, float partialTicks) {}
    public static void renderItemAndEffectIntoGui3D(class_1799 stack, int xPos, int yPos) {}
    public static void bindTexture(int texture) {}
    public static void setAlphaLimit(float limit) {}
    public static void resetColor() {}
    public static class_276 createFrameBuffer(class_276 fb) { return fb; }
    public static class_276 createFrameBuffer(class_276 fb, boolean depth) { return fb; }
    public static boolean needsNewFramebuffer(class_276 fb) { return false; }
    public static void drawRoundedGradientOutlinedRectangle(float x, float y, float x2, float y2, float radius, int color1, int color2, int color3) {}
}
