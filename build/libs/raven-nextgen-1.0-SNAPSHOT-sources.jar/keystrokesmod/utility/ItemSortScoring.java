package keystrokesmod.utility;

import net.minecraft.class_1743;
import net.minecraft.class_1753;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1820;
import net.minecraft.class_1821;
import net.minecraft.class_1829;

public final class ItemSortScoring {
    private ItemSortScoring() {
    }

    public static double getMeleeDamage(class_1799 stack) {
        if (stack == null) return 0.0D;
        if (stack.method_7909() instanceof class_1829) return 6.0D + getDurabilityTieBreaker(stack);
        if (stack.method_7909() instanceof class_1743) return 5.0D + getDurabilityTieBreaker(stack);
        return getDurabilityTieBreaker(stack);
    }

    public static double getMeleeSelectionScore(class_1799 stack) {
        return getMeleeDamage(stack);
    }

    public static double getBowDamage(class_1799 stack) {
        return stack != null && stack.method_7909() instanceof class_1753 ? 6.0D + getDurabilityTieBreaker(stack) : 0.0D;
    }

    public static double getBowSelectionScore(class_1799 stack) {
        return getBowDamage(stack);
    }

    public static double getToolSelectionScore(class_1799 stack) {
        if (stack == null) return 0.0D;
        if (stack.method_7909() instanceof class_1810) return 5.0D + getDurabilityTieBreaker(stack);
        if (stack.method_7909() instanceof class_1743) return 4.0D + getDurabilityTieBreaker(stack);
        if (stack.method_7909() instanceof class_1821) return 3.0D + getDurabilityTieBreaker(stack);
        if (stack.method_7909() instanceof class_1794) return 2.0D + getDurabilityTieBreaker(stack);
        if (stack.method_7909() instanceof class_1820) return 1.0D + getDurabilityTieBreaker(stack);
        return 0.0D;
    }

    public static double getAxeScore(class_1799 stack) {
        return stack != null && stack.method_7909() instanceof class_1743 ? getToolSelectionScore(stack) : 0.0D;
    }

    public static double getPickaxeScore(class_1799 stack) {
        return stack != null && stack.method_7909() instanceof class_1810 ? getToolSelectionScore(stack) : 0.0D;
    }

    public static double getShovelScore(class_1799 stack) {
        return stack != null && stack.method_7909() instanceof class_1821 ? getToolSelectionScore(stack) : 0.0D;
    }

    public static double getHoeScore(class_1799 stack) {
        return stack != null && stack.method_7909() instanceof class_1794 ? getToolSelectionScore(stack) : 0.0D;
    }

    public static double getShearsScore(class_1799 stack) {
        return stack != null && stack.method_7909() instanceof class_1820 ? getToolSelectionScore(stack) : 0.0D;
    }

    private static double getDurabilityTieBreaker(class_1799 stack) {
        if (stack == null || !stack.method_7963()) return 0.0D;
        int maxDurability = stack.method_7936();
        if (maxDurability <= 0) return 0.0D;
        int remainingDurability = maxDurability - stack.method_7919();
        return remainingDurability / (double) maxDurability / 1000.0D;
    }
}
