package keystrokesmod.utility;

import java.util.*;

public class ModuleUtils implements IMinecraftInstance {
    public static boolean isMoving() {
        return mc.field_1724 != null && (mc.field_1724.field_3913.field_3905 != 0 || mc.field_1724.field_3913.field_3907 != 0);
    }

    public static boolean isHoldingSword() {
        return false;
    }

    public static boolean isBlocking() {
        return false;
    }

    public static boolean isOnGround() {
        return mc.field_1724 != null && mc.field_1724.method_24828();
    }

    public static boolean isInWater() {
        return mc.field_1724 != null && mc.field_1724.method_5799();
    }

    public static boolean isInLava() {
        return mc.field_1724 != null && mc.field_1724.method_5771();
    }

    public static boolean isFlying() {
        return mc.field_1724 != null && mc.field_1724.method_31549().field_7479;
    }

    public static boolean isSprinting() {
        return mc.field_1724 != null && mc.field_1724.method_5624();
    }

    public static boolean isSneaking() {
        return mc.field_1724 != null && mc.field_1724.method_5715();
    }

    public static boolean isRiding() {
        return mc.field_1724 != null && mc.field_1724.method_5765();
    }

    public static boolean isCreative() {
        return mc.field_1724 != null && mc.field_1724.method_31549().field_7477;
    }

    public static boolean isSpectator() {
        return mc.field_1724 != null && mc.field_1724.method_7325();
    }
}