package keystrokesmod.utility;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BlockListHighlightMatcher {
    private static final Set<class_2248> highlightedBlocks = new HashSet<>();
    private static final List<class_2338> highlightedPositions = new ArrayList<>();
    
    public static void addBlock(class_2248 block) {
        highlightedBlocks.add(block);
    }
    
    public static void removeBlock(class_2248 block) {
        highlightedBlocks.remove(block);
    }
    
    public static void addPosition(class_2338 pos) {
        highlightedPositions.add(pos);
    }
    
    public static void removePosition(class_2338 pos) {
        highlightedPositions.remove(pos);
    }
    
    public static void clear() {
        highlightedBlocks.clear();
        highlightedPositions.clear();
    }
    
    public static boolean isHighlighted(class_1937 world, class_2338 pos) {
        if (highlightedPositions.contains(pos)) return true;
        class_2680 state = world.method_8320(pos);
        return highlightedBlocks.contains(state.method_26204());
    }
    
    public static Set<class_2248> getHighlightedBlocks() {
        return highlightedBlocks;
    }
    
    public static List<class_2338> getHighlightedPositions() {
        return highlightedPositions;
    }
}
