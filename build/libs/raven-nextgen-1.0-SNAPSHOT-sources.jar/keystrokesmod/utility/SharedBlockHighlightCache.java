package keystrokesmod.utility;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2338;

public class SharedBlockHighlightCache {
    private static final Map<class_2338, Long> blocks = new HashMap<>();

    public static void add(class_2338 pos) {
        blocks.put(pos, System.currentTimeMillis());
    }

    public static boolean contains(class_2338 pos) {
        return blocks.containsKey(pos);
    }

    public static void remove(class_2338 pos) {
        blocks.remove(pos);
    }

    public static void clear() {
        blocks.clear();
    }
}