package keystrokesmod;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2797;
import net.minecraft.class_310;
import keystrokesmod.clickgui.ClickGui;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.event.KeyPressEvent;
import meteordevelopment.orbit.EventBus;
import meteordevelopment.orbit.IEventBus;

public class Raven implements ClientModInitializer {
    public static boolean DEBUG = false;
    public static String clientName = "Raven bS";
    public static class_310 mc = class_310.method_1551();
    public static ModuleManager moduleManager;
    public static ClickGui clickGui;
    public static keystrokesmod.command.CommandManager commandManager;
    public static keystrokesmod.utility.profile.ProfileManager profileManager;
    public static keystrokesmod.utility.profile.Profile currentProfile;
    public static keystrokesmod.script.ScriptManager scriptManager;
    public static final IEventBus EVENT_BUS = new EventBus();
    
    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        clickGui = new ClickGui();
        commandManager = new keystrokesmod.command.CommandManager();
        profileManager = new keystrokesmod.utility.profile.ProfileManager();
        scriptManager = new keystrokesmod.script.ScriptManager();
        EVENT_BUS.subscribe(this);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }
    
    private void onTick(class_310 client) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        for (Module m : moduleManager.getModules()) {
            if (m.isEnabled()) m.onUpdate();
        }
    }
    
    @EventHandler
    public void onSendPacket(SendPacketEvent e) {
        if (e.getPacket() instanceof class_2797 chat) {
            if (commandManager.execute(chat.comp_945())) e.setCanceled(true);
        }
    }
    
    @EventHandler
    public void onKeyPress(KeyPressEvent e) {
        if (mc.field_1755 != null) return;
        for (Module m : moduleManager.getModules()) {
            if (m.getKeycode() == e.getKeyCode()) m.toggle();
        }
    }
    public static ModuleManager getModuleManager() { return moduleManager; }
    public static IEventBus getEventBus() { return EVENT_BUS; }
}
