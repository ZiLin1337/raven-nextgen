package keystrokesmod.mixin.impl.render;

import net.minecraft.client.render.entity.PlayerEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(PlayerEntityRenderer.class)
public class MixinPlayerEntityRenderer {
}
